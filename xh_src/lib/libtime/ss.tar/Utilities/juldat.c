/*
Program to to determine the jday
from a given date (yr/mo/day):
*/

#include <stdio.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, space0, sw;
    int       year, jday, month, day;
    int       Numday[12];
    int       i, j, k, n, sslen;


   if (argc < 3) usage(-1);
   n = argc - 1;

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'd':
                for(i=1; i<n; ++i)
                   sscanf( argv[++index], "%2d%2d%2d", &year, &month, &day );
                break;
            default:
                usage(-1);
        }
   }


Numday[0] =   0;
Numday[1] =  31;
Numday[2] =  59;
Numday[3] =  90;
Numday[4] = 120;
Numday[5] = 151;
Numday[6] = 181;
Numday[7] = 212;
Numday[8] = 243;
Numday[9] = 273;
Numday[10] = 304;
Numday[11] = 334;

if (year==76 || year==80 || year==84 || year==88 || year==92 || year==96) {
  Numday[2]  =  60;
  Numday[3]  =  91;
  Numday[4]  = 121;
  Numday[5]  = 152;
  Numday[6]  = 182;
  Numday[7]  = 213;
  Numday[8]  = 244;
  Numday[9]  = 274;
  Numday[10] = 305;
  Numday[11] = 335;
}

jday  = Numday[month-1] + day;
fprintf(stdout, "%d\n", jday);

}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: juldat -d YYMMDD\n");
   exit( exitstatus );
}

