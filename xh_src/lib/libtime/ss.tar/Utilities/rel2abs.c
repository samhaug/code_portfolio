/*
 * rel2abs - reads in file with 3 columns;
   x,y, dV (in percent!)
   and fac

   it writes:
   x,y, (1. + dV) * fac
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0;
    char      ss[120];
    float     fac;
    double    x, y, dV, V;
    FILE      *fopen();

   if (argc < 3) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'f':
                if ( sscanf( argv[++index], "%f", &fac ) != 1) usage (-1);
                break;
            default:
                usage(-1);
        }
   }

/*   fprintf(stdout,"In rel2abs: fac = %f\n", fac); */

   while ( fgets(ss,120,stdin) != NULL ) {
      sscanf(ss,"%lf %lf %lf", &x, &y, &dV);
      V = (1. + dV/100.) * fac;
      fprintf(stdout,"%lf %lf %lf\n", x, y, V);
   }

   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: rel2abs -f fac\n"); 
   exit( exitstatus );
}

