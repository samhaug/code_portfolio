#include <stdio.h>
#include <string.h>
#include <math.h>

// resample -- reads in file with 2 columns (i.e. seismogram)
// and resample it with NEWdt

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, err;
    int       nlines;
    char      ss[120];
    float     t[10000], f[10000];
    float     newdt, newt, maxt, newf;
    FILE      *ifl, *fopen();


if (argc != 4) err = usage(-1);

if ((ifl = fopen(argv[1],"r")) == NULL) {
  fprintf(stderr,"%s cannot be opened ...\n", ifl);
  exit(-1);
}
index = 1;

while ( ++index < argc && argv[index][0] == '-' ) {
     switch ( argv[index][1] ) {
         case 't':
             if ( sscanf( argv[++index], "%f", &newdt ) != 1) err= usage(-1);
             break;
         default:
             err= usage(-1);
     }
}
i=0;
while ( fgets(ss,120,ifl) != NULL && i<10000 ) {
   sscanf(ss,"%f %f", &t[i],&f[i]);
   i = i+1;
}
nlines = i-1;
maxt = t[nlines-1];
//fprintf(stdout,"nlines= %d  maxt= %f\n", nlines, maxt);

i=0;
while ( i*newdt <= maxt ) {
  newt = i*newdt;
  if (! interp(newt, t, f, &newf) ) {
     fprintf(stderr,"Error in interp() newt= %f\n", newt);
     exit(-1);
  }
  //fprintf(stdout,"newt= %f  newf= %f\n", newt, newf);
  fprintf(stdout,"%f  %f\n", newt, newf);
  i = i+1;
}


}

int interp(t,time,array,val)

float t;
float time[10000];
float array[10000];
float *val;

{
int i=0;
float da, dt, dv;
while (t > time[i] )
   i++;
dt = time[i] - time[i-1];
da = array[i]-array[i-1];
dv = da/dt;
*val =  array[i-1] + (t-time[i-1])*dv;
//fprintf(stdout,"INTERP i= %d  t= %f t1= %f t2 = %f\n", i, t,time[i-1],time[i]);
//fprintf(stdout,"INTERP v1= %f v2= %f val=%f \n", array[i-1],array[i], *val);
}

int    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: resample INFILE\n");
   exit( exitstatus );
}
