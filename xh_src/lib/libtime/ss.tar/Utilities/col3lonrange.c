/*
 * col3lonrange - reads in a file with 3 columns and
   make the range in longitude from -180 to +180
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    int       colnum;
    char      ss[120], file1[80], file2[80];
    double    x1,y1,z1;
    FILE     *fp1, *fopen();


   if (argc < 3) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case '1':
                if ( sscanf( argv[++index], "%s", file1 ) != 1) usage (-1);
                break;
            case 'c':
                if ( sscanf( argv[++index], "%d", &colnum ) != 1) usage (-1);
                if ( colnum > 3 ) usage (-1);
                break;
            default:
                usage(-1);
        }
   }
   fp1 = fopen(file1,"r");

   while ( fgets(ss,120,fp1) != NULL ) {
      sscanf(ss,"%lf %lf %lf", &x1, &y1, &z1);
      if        (colnum == 3) {
        if (z1 >=180. ) z1 = z1-360.;
      } else if (colnum == 2) {
        if (y1 >=180. ) y1 = y1-360.;
      } else if (colnum == 1) {
        if (x1 >=180. ) x1 = x1-360.;
      }
      fprintf(stdout,"%lf %lf %lf\n", x1,y1,z1);
   }
   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: col3lonrange -1 file1 -c [column <= 3]\n"); 
   fprintf(stderr,"\n");
   exit( exitstatus );
}

