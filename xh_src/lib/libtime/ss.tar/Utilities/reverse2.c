/*
 * reverse2 - reads in file with 2 floats and reverses it
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    int       colnum, nlines;
    char      ss[120];
    double    x[10000], y[10000];
    double    xmax, ymax;


   if (argc != 1) usage(-1);

     i=0;
     while ( fgets(ss,120,stdin) != NULL ) {
        sscanf(ss,"%lf %lf", &x[i], &y[i]);
        i++;
     }
     nlines = i-1;
     for (i=nlines; i>=0; --i) 
       fprintf(stdout,"%lf %lf\n", x[i], y[i]);

   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: reverse2 [no input] \n"); 
   exit( exitstatus );
}

