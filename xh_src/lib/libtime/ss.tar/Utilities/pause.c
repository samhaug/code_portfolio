//----------------------------------------------
//
// pause -
//
// waits for a key stroke to exit.
//
// Useful to stop the execution of a
// script until the user is prompted to
// "print any key to continue ..."
//
// Jeroen Ritsema, January 1998, Caltech
//----------------------------------------------

#include <stdio.h>

void pause();

main( argc, argv )
int   argc;
char       *argv[];
{
char sym;

fprintf(stdout,"print RETURN to continue ...");
scanf("%c",&sym);
}
