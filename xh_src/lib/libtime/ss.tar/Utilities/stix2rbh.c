/*
Program to turn the PYRL output from Lars into seismic profiles
for phase velocity computations in NARS_overtones
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

main(argc,argv)
int argc;
char **argv;
{
FILE *ifl;

int i;
int k;

float dep[3000],rho[3000],vs[3000],vp[3000],qs[3000],qp[3000];
float Z_flat[3000],Pval_flat[3000],Sval_flat[3000],Rval_flat[3000];

float Pval, Sval, Rval, QPval, QSval;
float dz, z0, z;
float EarthRad, flat;
float src_depth, dist, Ptime;

int   numsamp = 1024;
float dt      = 0.25;

char ss[140];

if ((ifl = fopen(argv[1],"r")) == NULL) {
  fprintf(stderr,"%s cannot be opened ...\n", ifl);
  exit(-1);
}

EarthRad = 6371.;
i=0;
while ( fgets(ss,140,ifl) != NULL ) {
   sscanf(ss,"%*f %f %*f %f %*f %*f %*f %f %f %f %f", &dep[i],&rho[i],&vs[i],&vp[i],&qs[i],&qp[i]);
   i = i+1;
}

fprintf(stdout,"MODEL.01\n");
fprintf(stdout,"ADIABAT_1650\n");
fprintf(stdout,"ISOTROPIC\n");
fprintf(stdout,"KGS\n");
fprintf(stdout,"SPHERICAL EARTH\n");
fprintf(stdout,"1-D\n");
fprintf(stdout,"CONSTANT VELOCITY\n");
fprintf(stdout,"LINE08\n");
fprintf(stdout,"LINE09\n");
fprintf(stdout,"LINE10\n");
fprintf(stdout,"LINE11\n");
fprintf(stdout,"H   VP    VS    RHO   QP  QS   ETAP ETAS  FREFP  FREPS\n");

z  = 0.;
//while (z < 3870.){
while (z < 1470.){
  dz = 20.;
  if (z < 1100.) dz = 20.;
  if (z <  330.) dz = 12.;
  if (z <  100.) dz =  6.;
  if (z <   33.) dz =  3.;
  z = z + dz;
  if (! interp(z, dep, vp, &Pval) ) {
     fprintf(stderr,"Error in interp() z= %f\n", z);
     exit(-1);
  }
  if (! interp(z, dep, vs, &Sval) ) {
     fprintf(stderr,"Error in interp() z= %f\n", z);
     exit(-1);
  }
  if (! interp(z, dep, rho, &Rval) ) {
     fprintf(stderr,"Error in interp() z= %f\n", z);
     exit(-1);
  }
  if (! interp(z, dep, qp, &QPval) ) {
     fprintf(stderr,"Error in interp() z= %f\n", z);
     exit(-1);
  }
  if (! interp(z, dep, qs, &QSval) ) {
     fprintf(stderr,"Error in interp() z= %f\n", z);
     exit(-1);
  }
  fprintf(stdout,"%4.2f %5.2f %5.2f %5.2f %4.1f %4.1f 0.0  0.0   1.0   1.0\n",
           dz, Pval, Sval, Rval, QPval, QSval);
}

}
  



int interp(z,dep,array,val)

float z;
float dep[3000];
float array[3000];
float *val;

{

int i=0;
float da, dz, dv; 

while (z > dep[i] )
   i++;

dz = dep[i] - dep[i-1];
da = array[i]-array[i-1];
dv = da/dz;

*val =  array[i-1] + (z-dep[i-1])*dv;

//fprintf(stdout,"INTERP i= %d  z= %f z1= %f z2 = %f\n", i, z,dep[i-1],dep[i]);
//fprintf(stdout,"INTERP v1= %f v2= %f val=%f \n", array[i-1],array[i], *val);
}
