/*
 * interp - reads in a x-y file and reads x1 from stdin
   and printf the y-value after interpolation
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j, nlines;
    char      ss[120];
    double    x[90000], y[90000];
    float     x1;


   if (argc < 3) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'x':
                if ( sscanf( argv[++index], "%f", &x1 ) != 1) usage (-1);
                break;
            default:
                usage(-1);
        }
   }

   i=0;
   while ( fgets(ss,120,stdin) != NULL ) {
      sscanf(ss,"%lf %lf", &x[i], &y[i]);
      i++;
   }
   nlines = i;
   for (i=0; i<nlines; ++i) {
     if (x1 >= x[i] && x1 <= x[i+1]) {
       fprintf(stdout,"%lf\n",(x1 -x[i])/(x[i+1]-x[i])*(y[i+1]-y[i]) + y[i]);
       exit( 0 );
     }
   }

}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: interp -x x1 \n"); 
   exit( exitstatus );
}

