/*
 setint - Take a double-float, and print out its integer value
    179.8  --> 179
    -34.5  --> -34
*/

#include <stdio.h>
#include <string.h>
#include <sunmath.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
   char     ss[120];
   double        f1;
   int          if1;


   if (argc != 1) usage(-1);

   fgets(ss,120,stdin);
   sscanf(ss,"%lf", &f1);
   if1 = f1;
   fprintf(stdout,"%d\n", if1);

exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: setint entry1\n"); 
   exit( exitstatus );
}

