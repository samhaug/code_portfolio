/*
 * binavg - determines average  value of values in column 3
   that are within x-range: [x, x+dx]
   
   binavg -x xmin xmax -d nx < inputfile
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

#define MAX  1000

main( argc, argv )
int   argc;
char       *argv[];
{
   int       index = 0, i, nx;
   double     xmin, xmax;
   double     x, dx, z;
   char      ss[120];

   double avg[MAX];
   int    cnt[MAX];

if (argc < 4) usage(-1);

while ( ++index < argc && argv[index][0] == '-' ) {
     switch ( argv[index][1] ) {
         case 'x':
             if ( sscanf( argv[++index], "%lf", &xmin ) != 1 ||
                  sscanf( argv[++index], "%lf", &xmax ) != 1) usage(-1);
             break;
         case 'd':
             if ( sscanf( argv[++index], "%d", &nx ) != 1) usage(-1);
             break;
         default:
             usage(-1);
     }
}
if (nx > MAX) {
  fprintf(stderr,"nx [= %d] should be less than %d\n", nx,MAX);
  exit (0);
}
if (xmin > xmax) usage (-1);



dx = (xmax-xmin)/nx;

while (fgets(ss,120,stdin) != NULL ) {
  sscanf(ss,"%lf %lf", &x, &z);
  i = lrint((x - xmin)/dx);
  
  if (i<nx) {
    avg[i] = avg[i] + z;
    cnt[i] = cnt[i] + 1; 
  }
}
  
for (i=0; i<nx; ++i) {
  if (cnt[i] > 0) avg[i] = avg[i] / cnt[i];
  fprintf(stdout,"%lf %lf\n", xmin + (i*1.+0.5)*dx, avg[i]);
}


exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: binavg -x xmin xmax -d nx\n"); 
   exit( exitstatus );
}
