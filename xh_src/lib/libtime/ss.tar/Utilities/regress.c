/*
 * regress - filend best-fitting line -
   y=ax+b (option=1) or y=ax (options=0) -
   to x-y data set
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i;
    int       option, numpoints;
    char      ss[120];
    double    x[10000], y[10000];
    double    ata[2][2], ainv[2][2], atd[2];
    double    det, slope, intercept;


   if (argc < 3) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'n':
                if ( sscanf( argv[++index], "%d", &option ) != 1) usage (-1);
                if ( option > 2 ) usage (-1);
                break;
            default:
                usage(-1);
        }
   }

   ata[0][0] = 0.; ata[0][1] = 0.;
   ata[1][0] = 0.; ata[1][1] = 0.;
   atd[0]    = 0.; atd[1]    = 0.;
   i = 0;
   fprintf(stdout,"numpoints= %d\n", numpoints);
   if (option == 1) {
     while ( fgets(ss,120,stdin) != NULL ) {
        i++;
   fprintf(stdout,"i= %d\n", i);
        sscanf(ss,"%lf %lf", &x[i], &y[i]);
        ata[0][0] = ata[0][0] + x[i]*x[i];
        ata[0][1] = ata[0][1] + x[i];
     }
   }
   numpoints = i;
   ata[1][1] = ata[0][0];
   ata[1][0] = ata[0][1];
   for (i=0; i<numpoints; ++i) {
     atd[0] = atd[0] + x[i]*y[i];   
     atd[1] = atd[1] + y[i];   
   }

   det = ata[0][0]*ata[1][1] - ata[1][0]*ata[0][1];
   ainv[0][0] =  ata[1][1]/det;
   ainv[1][1] =  ata[0][0]/det;
   ainv[0][1] = -ata[0][1]/det;
   ainv[1][0] = -ata[1][0]/det;
   slope     = ainv[0][0]*atd[0] + ainv[0][1]*atd[1];
   intercept = ainv[1][0]*atd[0] + ainv[1][1]*atd[1];

   fprintf(stdout,"Slope= %9.2f Intercept= %9.2f\n", slope, intercept);
   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: regress -n option [1 or 2]\n"); 
   exit( exitstatus );
}

