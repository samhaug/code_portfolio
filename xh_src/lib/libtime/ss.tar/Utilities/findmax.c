// findmax - reads in a x-y file and finds
// the maximum y-value between x1 and x2

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    int       colnum;
    char      ss[120], file[80];
    float     x1,x2;
    float     x,y,maxx,maxy;
    FILE     *fp, *fopen();


   if (argc < 3) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'f':
                if ( sscanf( argv[++index], "%s", file ) != 1) usage (-1);
                break;
            case 'x':
                if ( sscanf( argv[++index], "%f", &x1 ) != 1) usage (-1);
                if ( sscanf( argv[++index], "%f", &x2 ) != 1) usage (-1);
                break;
            default:
                usage(-1);
        }
   }
   fp = fopen(file,"r");
   

   maxy = -999.;
   maxx = -999.;
   while ( fgets(ss,120,fp) != NULL ) {
      sscanf(ss,"%f %f", &x, &y);
      if        (x >= x1 && x <= x2) {
        if (y > maxy) {
          maxy = y;
          maxx = x;
        }
      }
   }
   fprintf(stdout,"%f %f\n", maxx,maxy);
   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: findmax -f file -x x1 x2\n"); 
   fprintf(stderr,"\n");
   fprintf(stderr,"Reads in a x-y file and finds the\n");
   fprintf(stderr,"maximum y value between x1 and x2\n");
   exit( exitstatus );
}

