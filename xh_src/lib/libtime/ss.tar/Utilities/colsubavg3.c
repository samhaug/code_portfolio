/*
 * colsubavg3 - reads in file with 3 columns and subtract the average value of the 3rd
   xolumn from the 3rd column :
       x1, y1, z1 - avg(z1,z2,z3,z4, ...)
       x2, y2, z2 - avg(z1,z2,z3,z4, ...)
       x3, y3, z3 - avg(z1,z2,z3,z4, ...)
       x4, y4, z4 - avg(z1,z2,z3,z4, ...)
       ....
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    char      ss[120];
    double    x[20000],y[20000],z[20000];
    double    avg;


   if (argc < 1) usage(-1);

   j = -1;
   avg = 0.;
   while ( fgets(ss,120,stdin) != NULL ) {
      ++j;
      sscanf(ss,"%lf %lf %lf", &x[j], &y[j], &z[j]);
      avg = avg + z[j];
   }
   avg = avg/(j+1);
   fprintf(stderr,"j= %d  avg= %lf\n", j, avg);
   for (i=0; i<=j; ++i) {
      fprintf(stdout,"%lf %lf %lf\n", x[i], y[i], z[i]-avg);
   }
   
   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: colsubavg3 < file [... with 3 columns]\n"); 
   exit( exitstatus );
}

