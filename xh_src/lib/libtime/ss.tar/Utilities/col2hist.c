/*
 * col2hist -- make histogram style file for psxy plotting
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

void usage();

int main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j, n, npoints;
    int       colnum;
    char      ss[120], infile[80];
    double    x1[10000],y1[10000], dx;
    double    x2[10000],y2[10000];
    FILE     *fp1, *fopen();


   if (argc < 4) usage(-1);

   if ( sscanf( argv[1], "%s", infile ) != 1) usage (-1);
   index = 1;
   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'x':
                if ( sscanf( argv[++index], "%lf", &dx ) != 1) usage (-1);
                if ( colnum > 2 ) usage (-1);
                break;
            default:
                usage(-1);
        }
   }

   // reading data
   fp1 = fopen(infile,"r");
   i=0;
   while ( fgets(ss,120,fp1) != NULL ) {
      sscanf(ss,"%lf %lf", &x1[i], &y1[i]);
      i++;
   }
   n = i;

   npoints = (int) (x1[n-1]-x1[0])/dx + 1 + 1;
   //fprintf(stdout,"npoints= %d\n", npoints);
   for (j=0; j<npoints;j++) {
     x2[j] = j*dx + x1[0];
     y2[j] = 0.;
     for (i=0; i<n;i++) {
       if ( fabsf(x2[j]-x1[i]) < 0.001 ) y2[j] = y1[i];
     }
     if (j == 0) {
     fprintf(stdout,"%lf %lf\n", x2[j]-dx/2, 0.);
     }
     fprintf(stdout,"%lf %lf\n", x2[j]-dx/2, y2[j]);
     fprintf(stdout,"%lf %lf\n", x2[j]+dx/2, y2[j]);
     if (j == npoints-1) {
     fprintf(stdout,"%lf %lf\n", x2[j]+dx/2, 0.);
     }
   }

   fprintf(stdout,"%lf %lf\n",x2[npoints-1]+dx,0.);

   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: col2hist infile\n"); 
   fprintf(stderr,"\n");
   fprintf(stderr,"Reads in a file with 2 columns and\n");
   fprintf(stderr,"outputs the outline of a histgram for psxy\n");
   exit( exitstatus );
}

