/*
 * col3rmv - reads in a file with 3 columns and
   removes the row if the value in the nth
   (1, 2 or 3) column if the value is less than x
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    int       colnum;
    char      ss[120], file1[80], file2[80];
    double    x1,y1, val;
    FILE     *fp1, *fopen();


   if (argc < 3) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case '1':
                if ( sscanf( argv[++index], "%s", file1 ) != 1) usage (-1);
                break;
            case 'c':
                if ( sscanf( argv[++index], "%d", &colnum ) != 1) usage (-1);
                if ( colnum > 3 ) usage (-1);
                break;
            case 'x':
                if ( sscanf( argv[++index], "%lf", &val ) != 1) usage (-1);
                break;
            default:
                usage(-1);
        }
   }
   fp1 = fopen(file1,"r");
   

   while ( fgets(ss,120,fp1) != NULL ) {
      sscanf(ss,"%lf %lf", &x1, &y1);
      if        (colnum == 3) {
        if (y1 < val) 
          fprintf(stdout,"%lf %lf\n", x1, y1);
      } else if (colnum == 2) {
        if (y1 < val) 
          fprintf(stdout,"%lf %lf\n", x1, y1);
      } else if (colnum == 1) {
        if (y1 < val) 
          fprintf(stdout,"%lf %lf\n", x1, y1);
      }
   }
   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: rmv3col -1 file1 -c [column <= 3] -x val\n"); 
   fprintf(stderr,"\n");
   fprintf(stderr,"Reads in a file with 3 columns and\n");
   fprintf(stderr,"removes the row if the value in the nth\n");
   fprintf(stderr,"(1, 2 or 3) column if the value is less than x\n");
   exit( exitstatus );
}

