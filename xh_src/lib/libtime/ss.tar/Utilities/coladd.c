/*
 * coladd - reads in 2 one-column files and add them up 
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    char      ss1[120], ss2[120], file1[80], file2[80];
    double    x1,x2;
    FILE     *fp1, *fp2, *fopen();


   if (argc < 2) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case '1':
                if ( sscanf( argv[++index], "%s", file1 ) != 1) usage (-1);
                break;
            case '2':
                if ( sscanf( argv[++index], "%s", file2 ) != 1) usage (-1);
                break;
            default:
                usage(-1);
        }
   }
   fp1 = fopen(file1,"r");
   fp2 = fopen(file2,"r");
   
   while ( fgets(ss1,120,fp1) != NULL ) {
      sscanf(ss1,"%lf", &x1);
      fgets(ss2,120,fp2);
      sscanf(ss2,"%lf", &x2);
      fprintf(stdout,"%lf\n", x1+x2);
   }
   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: coladd -1 file1 -2 file2\n"); 
   exit( exitstatus );
}

