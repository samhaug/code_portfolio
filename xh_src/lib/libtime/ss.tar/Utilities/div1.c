/*
 * div1 - reads in a one-column files and divides by X 
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    char      ss1[120], ss2[120], file1[80], file2[80];
    double    v, x;
    FILE     *fp1, *fp2, *fopen();


   if (argc < 2) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'd':
                if ( sscanf( argv[++index], "%lf", &x ) != 1) usage (-1);
                break;
            default:
                usage(-1);
        }
   }
   
   while ( fgets(ss1,120,stdin) != NULL ) {
      sscanf(ss1,"%lf", &v);
      fprintf(stdout,"%lf\n", v/x);
   }
   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: div1 -d X < file\n"); 
   exit( exitstatus );
}

