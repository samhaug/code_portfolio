/*
 * abs3 - reads in file with 3 columns and outputs the
           absolute value of the nth (1, 2 or 3) column.
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    int       colnum, nlines;
    char      ss[120];
    double    x, y, z;
    double    max;


   if (argc < 3) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'n':
                if ( sscanf( argv[++index], "%d", &colnum ) != 1) usage (-1);
                if ( colnum > 3 ) usage (-1);
                break;
            default:
                usage(-1);
        }
   }

   while ( fgets(ss,120,stdin) != NULL ) {
      sscanf(ss,"%lf %lf %lf", &x, &y, &z);
      if        (colnum == 1) {
         fprintf(stdout,"%lf %lf %lf\n", fabs(x), y, z);
      } else if (colnum == 2) {
         fprintf(stdout,"%lf %lf %lf\n", x, fabs(y), z);
      } else if (colnum == 3) {
         fprintf(stdout,"%lf %lf %lf\n", x, y, fabs(z));
      }
   } 

   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: abs3 -n column [column <= 3] \n"); 
   exit( exitstatus );
}

