/*
Program to turn the PYRL output from Lars into seismic profiles
for FK
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

main(argc,argv)
int argc;
char **argv;
{
FILE *ifl;

int i, n_layers=0;
int k;

float thck,rho,vs,vp,qs,qp;
float depth;

char ss[140];

if ((ifl = fopen(argv[1],"r")) == NULL) {
  fprintf(stderr,"%s cannot be opened ...\n", ifl);
  exit(-1);
}

depth = 0.;
while ( fgets(ss,140,ifl) != NULL ) {
   sscanf(ss,"%f %f %f %f %f %f", &thck,&vp,&vs,&rho,&qp,&qs);
   depth = depth+thck;
   fprintf(stdout,"%10.4f %9.4f %9.4f %9.4f\n", depth,vp,vs,rho,qp,qs);
}

}
