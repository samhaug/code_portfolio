/*
 * mkBulkSound - reads 2 files, each with 3 columns;
   x,y, Vp
   x,y, Vs
   
   it writes 
   x,y  BulkSound
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    int       colnum, nlines;
    char      ssP[120], ssS[120], inP[30], inS[30];
    double    x, y, vp, vs, bulksound;
    float     tmin = 0.;
    FILE      *fP, *fS, *fopen();

   if (argc < 5) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'p':
                if ( sscanf( argv[++index], "%s", inP ) != 1) usage (-1);
                break;
            case 's':
                if ( sscanf( argv[++index], "%s", inS ) != 1) usage (-1);
                break;
            default:
                usage(-1);
        }
   }

   fP = fopen(inP,"r");
   fS = fopen(inS,"r");
   i=0;
   while ( fgets(ssP,120,fP) != NULL ) {
      fgets(ssS,120,fS);
      sscanf(ssP,"%lf %lf %lf", &x, &y, &vp);
      sscanf(ssS,"%lf %lf %lf", &x, &y, &vs);
      bulksound = vp*vp -4./3.*vs*vs;
      bulksound = sqrt(bulksound);
      fprintf(stdout,"%lf %lf %lf\n", x, y, bulksound);
   }

   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: mkBulkSound -p Vp_file [x,y,Vp] -s Vs_file [x,y,Vs]\n"); 
   fprintf(stderr,"Generates BulkSound velocity file [x,y,Vb]\n"); 
   exit( exitstatus );
}

