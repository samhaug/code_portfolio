//-------------------------------------------------------------
//  linesel - displays only a selection (max=50) of
//  lines (specified with -l) of a file (STDIN) 
//
//  Jeroen Ritsema, Sep 2004, IPG Paris
//-------------------------------------------------------------

#include <stdio.h>
#include <string.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
   int       index = 0, space0, sw;
   int       line[50], begch[50], endch[50];
   int       i, j, l, n, sslen;
   char      ss[120];

if (argc < 3) usage(-1);
n = argc - 1;
for(l=0; l<50; ++l) {
  line[l]=-1;
}

while ( ++index < argc && argv[index][0] == '-' ) {
     switch ( argv[index][1] ) {
         case 'l':
             for(i=1; i<n; ++i)
                sscanf( argv[++index], "%d", &line[i] );
             break;
         default:
             usage(-1);
     }
}

l=0;
while (fgets(ss,120,stdin) != NULL ) {
   l=l+1;
   for(i=1;i<=n;i++) { 
      if (l == line[i]) {
         fprintf(stdout,"%s",ss);
      }
   }
}
exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: linesel -l field1 field2 ....\n"); 
   exit( exitstatus );
}

