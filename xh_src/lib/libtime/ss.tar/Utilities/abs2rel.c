/*
 * abs2rel - reads in file with 3 columns;
   x,y, V (absolute velocities!)
   and Vmod

   it writes:
   x,y, (V - Vmod)/Vmod * 100.
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0;
    char      ss[120];
    float     Vmod;
    double    x, y, V, dV;
    FILE      *fopen();

   if (argc < 3) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'f':
                if ( sscanf( argv[++index], "%f", &Vmod ) != 1) usage (-1);
                break;
            default:
                usage(-1);
        }
   }

/*   fprintf(stdout,"In rel2abs: Vmod = %f\n", Vmod); */

   while ( fgets(ss,120,stdin) != NULL ) {
      sscanf(ss,"%lf %lf %lf", &x, &y, &V);
      dV = (V - Vmod)/Vmod * 100.;
      fprintf(stdout,"%lf %lf %lf\n", x, y, dV);
   }

   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: abs2rel -f Vmod\n"); 
   exit( exitstatus );
}

