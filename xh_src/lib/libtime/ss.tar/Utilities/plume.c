/*
 * plume - prints out a file with a gaussian
   distribution of seismic velocity anomalies
   about lat/lon
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

#define MAX  1000

main( argc, argv )
int   argc;
char       *argv[];
{
   int       index = 0, i, j, numrad;
   float     lat, lon;
   float     plat, plon;
   float     width, stp, max;
   float    rad, drad, anom;
   float     delta, az, baz;
   char      ss[120];
   void      distaz(), distazlatlon();


if (argc < 7) usage(-1);

while ( ++index < argc && argv[index][0] == '-' ) {
     switch ( argv[index][1] ) {
         case 'l':
             if ( sscanf( argv[++index], "%f", &plat ) != 1 ||
                  sscanf( argv[++index], "%f", &plon ) != 1) usage(-1);
             break;
         case 'w':
             if ( sscanf( argv[++index], "%f", &width ) != 1) usage(-1);
             break;
         case 'm':
             if ( sscanf( argv[++index], "%f", &max ) != 1) usage(-1);
             break;
         default:
             usage(-1);
     }
}

width = width/111.19493;

/*------------------------------------------------*/
/* Gaussian Plume */
/* -- sample the medium every 10th of the plume
      width out to 10 degrees from its center ... */
/*------------------------------------------------*/

if (1==0) {
drad =   width / 10.;
numrad = 30;

fprintf(stdout,"%f %f %9.2e\n", plon, plat, max);
for(j=1; j<numrad; ++j) {
  rad = j*drad; 
  for(i=0;i<60; ++i) {
    az = i*6.;
    distazlatlon(plat,plon,rad,az,&lat,&lon);
    anom = rad/width;
    anom = -anom*anom;
    anom = exp(anom);
    fprintf(stdout,"%f %f %9.2e\n", lon, lat, max*anom);
  }
}
lat = 89.;
while ( lat >= -89.) {
  lon = -180.;
  while (lon <= 180.) {
    distaz(plat,plon,lat,lon,&delta,&az,&baz);
    if (delta/width >= 3.) 
      fprintf(stdout,"%f %f %9.2e\n", lon, lat, 0.01);
    lon = lon + 3.;
  }
  lat = lat - 3;
}
}

/*------------------------------------------------*/
/* BoxCar Plume */
/* -- sample the medium every 10th of the plume
      width out to 10 degrees from its center ... */
/*------------------------------------------------*/

if (1==1) {
drad =   width / 10.;
numrad = 10;

fprintf(stdout,"%f %f %9.2e\n", plon, plat, max);
for(j=1; j<numrad; ++j) {
  rad = j*drad;
  for(i=0;i<60; ++i) {
    az = i*6.;
    distazlatlon(plat,plon,rad,az,&lat,&lon);
    anom = 1.;
    fprintf(stdout,"%f %f %9.2e\n", lon, lat, max*anom);
  }
}
lat = 89.;
while ( lat >= -89.) {
  lon = -180.;
  while (lon <= 180.) {
    distaz(plat,plon,lat,lon,&delta,&az,&baz);
    if (delta/width >= 1.) 
      fprintf(stdout,"%f %f %9.2e\n", lon, lat, 0.01);
    lon = lon + 3.;
  }
  lat = lat - 3;
}

exit( 0 );
}
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: plume -l lat lon -m max -w width [km] -d step [deg]\n"); 
   exit( exitstatus );
}
 
/*---------------------------------------------------*/
/*
  Given Lat1, Lon1, this routine calculates Lat2, Lon2, 
  located at a distance Dist and azimuth Azi (clockwise from north).
*/
 
void distazlatlon(Lat1,Lon1,Dist,Az,Lat2,Lon2)
   float Lat1, Lon1, Dist,Az;
   float *Lat2, *Lon2;
{
   float lt1, ln1, dst,azm;
   float Theta, Phi, Theta2, Phi2;
   float DegToRad;

   float v[3];

   FILE *ff1, *fopen();
 

DegToRad = atan(1.) * 4./180.;


Theta = 90. - Lat1;
Phi   = Lon1;

lt1  = Lat1*DegToRad;
ln1  = Lon1*DegToRad;
dst  = Dist*DegToRad;
azm  = Az*DegToRad;
Theta *= DegToRad;
Phi   *= DegToRad;

v[0] = 1.; v[1] = 0.; v[2] = 0.;

Rotate_E(v, -1.0*dst);

Rotate_A(v, -1.0*azm);

Rotate_E(v, -1.0*lt1);

Rotate_M(v, -1.0*ln1);


Theta2 = acos( v[2] );
Phi2   = acos( v[0]/sin(Theta2) );
if (v[1] < 0.)    Phi2 = -Phi2;
if (Phi2 < -180.) Phi2 = Phi2 + 360.;

*Lat2 = 90. - Theta2/DegToRad;
*Lon2 = Phi2/DegToRad;



return;

}



/*-----------------------------------------------------------------*/
Rotate_M(v,phi)

float v[3];
float phi;
{

float a[3][3];
float x[3];
int i, j;

a[0][0] =  cos(phi); a[0][1] =  sin(phi); a[0][2] = 0.;
a[1][0] = -sin(phi); a[1][1] =  cos(phi); a[1][2] = 0.;
a[2][0] =  0.;       a[2][1] =  0.;       a[2][2] = 1.;

for(i=0;i<3;++i) {
  x[i] = 0.;
  for(j=0;j<3;++j) 
    x[i] = x[i] + a[i][j]*v[j]; 
  }

for(i=0;i<3;++i) 
  v[i] = x[i];

}

/*-----------------------------------------------------------------*/
Rotate_E(v,phi)

float v[3];
float phi;
{

float a[3][3];
float x[3];
int i, j;

a[0][0] =  cos(phi); a[0][1] = 0.; a[0][2] = sin(phi);
a[1][0] =  0.;       a[1][1] = 1.; a[1][2] = 0.;
a[2][0] = -sin(phi); a[2][1] = 0.; a[2][2] = cos(phi);

for(i=0;i<3;++i) {
  x[i] = 0.;
  for(j=0;j<3;++j) 
    x[i] = x[i] + a[i][j]*v[j]; 
  }

for(i=0;i<3;++i) 
  v[i] = x[i];

}

/*-----------------------------------------------------------------*/
Rotate_A(v,phi)

float v[3];
float phi;
{

float a[3][3];
float x[3];
int i, j;

a[0][0] =  1.; a[0][1] = 0.;        a[0][2] = 0.;
a[1][0] =  0.; a[1][1] =  cos(phi); a[1][2] = -sin(phi);
a[2][0] =  0.; a[2][1] =  sin(phi); a[2][2] = cos(phi);

for(i=0;i<3;++i) {
  x[i] = 0.;
  for(j=0;j<3;++j) 
    x[i] = x[i] + a[i][j]*v[j]; 
  }

for(i=0;i<3;++i) 
  v[i] = x[i];

}

