/*
 * chlen - Calculates the length of a character string
 */

#include <stdio.h>
#include <string.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, field1, field2;
    char      ss[120];


   if (argc > 1) usage(-1);

   if (fgets(ss,120,stdin) == NULL ) usage (-1);
   
   i = 0;
   while (ss[i] != '\0') { 
       i++;
   }
   fprintf(stdout,"%d\n",i-1);

exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: chlen\n"); 
   exit( exitstatus );
}

