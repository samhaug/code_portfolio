/*
 * coladd2 - reads in two files with 2 columns and
   divides the values in the nth (1 or 2) column of file 1 by the
   correspoding column values of file 2.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    int       colnum;
    char      ss[120], file1[80], file2[80];
    double    x1,y1;
    double    x2,y2;
    FILE *fp1, *fp2, *fopen();


   if (argc < 3) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case '1':
                if ( sscanf( argv[++index], "%s", file1 ) != 1) usage (-1);
                break;
            case '2':
                if ( sscanf( argv[++index], "%s", file2 ) != 1) usage (-1);
                break;
            case 'c':
                if ( sscanf( argv[++index], "%d", &colnum ) != 1) usage (-1);
                if ( colnum > 2 ) usage (-1);
                break;
            default:
                usage(-1);
        }
   }
   fp1 = fopen(file1,"r");
   fp2 = fopen(file2,"r");
   

   if (colnum == 2) {
     while ( fgets(ss,120,fp1) != NULL ) {
        sscanf(ss,"%lf %lf", &x1, &y1);
        fgets(ss,120,fp2);
        sscanf(ss,"%lf %lf", &x2, &y2);
        if (x1 == x2) {
          if (y2 != 0.)
          fprintf(stdout,"%lf %lf\n", x1, y1/y2);
        } else {
          fprintf(stderr,"x1 is not equal to x2 ..\n");
          exit (-1);
        }
     }
   } else if (colnum == 1) {
     while ( fgets(ss,120,fp1) != NULL ) {
        sscanf(ss,"%lf %lf", &x1, &y1);
        fgets(ss,120,fp2);
        sscanf(ss,"%lf %lf", &x2, &y2);
        if (y1 == y2) {
          if (x2 != 0.)
          fprintf(stdout,"%lf %lf\n", x1/x2, y1);
        } else {
          fprintf(stderr,"y1 is not equal to y2 ..\n");
          exit (-1);
        }
     }
   }

   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: coldiv2 -1 file1 -2 file2 -c [column <= 2] \n"); 
   fprintf(stderr,"\n");
   fprintf(stderr,"Reads in two files with 2 columns and divides the values in the nth\n");
   fprintf(stderr,"(1 or 2) column of file 1 by those in the nth column of file 2\n");
   exit( exitstatus );
}

