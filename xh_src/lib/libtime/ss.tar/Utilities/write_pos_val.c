// Takes an x-y file and writes
// x-y if y>=0
// and writes
// x-0 if y<0

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <malloc.h>

main(argc,argv)
int argc;
char *argv[];
{
float x,y;
float first_x;
FILE *ifl, *fopen();

char ss[80];

int ierr;
int i;

int usage();

if(argc != 2) {
   ierr = usage();
   exit(ierr);
}
if ((ifl = fopen(argv[1],"r")) == NULL) {
     ierr = usage();
     return(ierr);
}

i=0;
while ( fgets(ss,80,ifl) != 0) {
 sscanf(ss,"%f %f", &x, &y);
 if ( i == 0 ) {
   first_x = x;
   if ( y > 0. ) {
     fprintf(stdout,"%f %f\n",x,0.); 
   }
 }   
 if ( y > 0.) {
   fprintf(stdout,"%f %f\n",x,y); 
 } else {
   fprintf(stdout,"%f %f\n",x,0.); 
 }
 i=i+1;
}
fprintf(stdout,"%f %f\n",x,0.); 
fprintf(stdout,"%f %f\n",first_x,0.); 


fclose(ifl);
exit (0);
}

int usage()
{
  fprintf(stderr,"Usage: write_pos_val FILE [x-y file]\n");
  fprintf(stderr,"prints [x,y] if y>=0, and [x,0] if not\n");
  return(-1);
}
