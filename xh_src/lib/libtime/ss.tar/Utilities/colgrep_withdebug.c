/*
 * colgrep - displays specified columns on a given input line
   e.g., 

  prompt> echo a b c d e f | colgrep -c 1 4 2  
         produces  "a d b"
  prompt> 
 *
 */

#include <stdio.h>
#include <string.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, space0, sw;
    int       field[20], begch[20], endch[20];
    int       i, j, k, n, sslen;
    char      ss[120];


   if (argc < 4) usage(-1);
   n = argc - 1;
   for(i=0; i<20; ++i) {
     field[i]=0; begch[i]=0; endch[i]=0;
   }

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'c':
                for(i=1; i<n; ++i)
                   sscanf( argv[++index], "%d", &field[i] );
                break;
            default:
                usage(-1);
        }
   }

   if (fgets(ss,120,stdin) == NULL ) usage (-1);

/*
   for(i=1; i<n; ++i) 
     fprintf(stdout," i= %d field= %d\n", i, field[i]);
*/

   
   sslen = strlen(ss);
/*   fprintf(stdout,"sslen=%d %s\n", sslen, ss); */

/* See whether the line starts with spaces ...: */
   space0 = -1;
   if( ss[0] == ' ') {
     j=0; 
     while(ss[j] == ' ') {
       space0 = j;
       j++;
     }
   }

   k = 1;
   sw = 0;
   for(i=space0+1; i<sslen; ++i) {
/*   fprintf(stdout,"sw=%d i=%d ss_i= %c\n", sw, i, ss[i]); */
     if (sw == 0) {
       if ( ss[i] != ' ') {
         begch[k] = i;
         sw = 1;
       }
     }
     if (sw == 1) {
       if ( ss[i] == ' ' || i == sslen-1 ) {
         endch[k] = i-1;
         sw = 0;
         k++;
       }
     }
/*   fprintf(stdout,"sw=%d k=%d i=%d begch_k=%d endch_k=%d\n", sw,k,i,begch[k],endch[k]); */
   }
/*
   for(k=1; k<20; ++k) 
     fprintf(stdout,"k=%d  begch_k= %d endch_k= %d\n", k, begch[k], endch[k]);
*/

   for (k=1; k<n;++k) {
      for(i=begch[field[k]]; i<=endch[field[k]]; ++i)
          fprintf(stdout,"%c", ss[i]);
      fprintf(stdout," ");
   }
   
fprintf(stdout,"\n");
   

      

exit( 0 );
}



void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: colgrep -c field1 field2 ....\n"); 
   exit( exitstatus );
}

