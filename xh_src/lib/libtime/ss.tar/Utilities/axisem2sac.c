#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <math.h>

#define MAXPOINTS 262144
#define NSTA      11

#define SAC_STRING_LENGTH   -1


int main(argc,argv)
int argc;
char *argv[];
{

float   t[MAXPOINTS];
float   d[MAXPOINTS], ddummy[MAXPOINTS];
float   b, delta, e;
float   evla, evlo, evdp;
float   stla, stlo;
float   cmpaz, cmpinc;

int     npts;
int     i;
int     index;
int     ierr;
int     true   =   1;
int     false  =   0;

FILE   *ifl, *ofl, *fopen();

char    kevnm[NSTA];
char    ss[120];

int usage();
void wsac0(), newhdr();
void setfhv(),setihv(), setkhv(), setlhv(), setnhv();


if (argc < 3) {
  ierr = usage();
  exit(ierr);
}
// specfem seismogram
if ((ifl = fopen(argv[1],"r")) == NULL) {
    ierr = usage();
    exit(ierr);
}
// reading the data
i=0;
while (fgets(ss,120,ifl) != NULL) {
   if ( i>(MAXPOINTS-1) ){
      fprintf(stderr,"Number of points higher than MAXPOINTS\n");
      fprintf(stderr,"Exiting ...\n");
   }
   sscanf(ss,"%f %f", &t[i], &d[i]);
   i++;
}
fclose(ifl);

// defaults
evla = 90.;
evlo = 0.;
evdp = 0.;
stla = 0.;
stlo = 0.;
cmpaz = cmpinc = 0.;
strcpy(kevnm,"000000A");

index = 2;
while ( ++index < argc && argv[index][0] == '-' ) {
  switch ( argv[index][1] ) {
     // event depth
     case 'e':
        if ( sscanf( argv[++index], "%f", &evla ) != 1) {
            ierr = usage();
        }
        if ( sscanf( argv[++index], "%f", &evlo ) != 1) {
            ierr = usage();
        }
        if ( sscanf( argv[++index], "%f", &evdp ) != 1) {
            ierr = usage();
        }
        break;
     // station location
     case 's':
        if ( sscanf( argv[++index], "%f", &stla ) != 1) {
            ierr = usage();
        }
        if ( sscanf( argv[++index], "%f", &stlo ) != 1) {
            ierr = usage();
        }
        break;
     // component info
     case 'i':
        if ( sscanf( argv[++index], "%f", &cmpaz )  != 1) {
            ierr = usage();
        }
        if ( sscanf( argv[++index], "%f", &cmpinc ) != 1) {
            ierr = usage();
        }
        break;
     // cmt code
     case 'c':
        if ( sscanf( argv[++index], "%s", kevnm )  != 1) {
            ierr = usage();
        }
        break;
     default:
        ierr = usage();
        exit(ierr);
  }
}

npts   = i;
b      = 0.;
delta  = t[4]-t[3];
e = (npts - 1) * delta;
// check that samples are evenly spaced
for(i=1; i< npts;i++) {
   if ( fabsf(t[i]-t[i-1]-delta) > 0.001 ) { 
      fprintf(stderr,"Spacing between samples i= %d and %d is not delta= %f\n", i, i+1, delta);
      exit(-1);
   }
}

newhdr();
setihv("IFTYPE", "ITIME",   &ierr , strlen("IFTYPE"), strlen("ITIME"));
setihv("IZTYPE", "IB",      &ierr , strlen("IZTYPE"), strlen("IB"));
setfhv("B",      &b,        &ierr , strlen("B"));
setlhv("LEVEN",  &true,     &ierr , strlen("LEVEN"));
setfhv("DELTA",  &delta,    &ierr , strlen("DELTA")) ;
setnhv("NPTS",   &npts,     &ierr, strlen("NPTS"));
setfhv("EVLA",   &evla,     &ierr, strlen("EVLA"));
setfhv("EVLO",   &evlo,     &ierr, strlen("EVLO"));
setfhv("EVDP",   &evdp,     &ierr, strlen("EVDP"));
setfhv("STLA",   &stla,     &ierr, strlen("STLA"));
setfhv("STLO",   &stlo,     &ierr, strlen("STLO"));
setkhv("KEVNM",  &kevnm[0], &ierr, strlen("KEVNM"), SAC_STRING_LENGTH);
setfhv("CMPAZ",  &cmpaz,    &ierr, strlen("CMPAZ"));
setfhv("CMPINC", &cmpinc,   &ierr, strlen("CMPINC"));


fprintf(stdout,"SAC-file: %s CMT= --%7s-- with npts= %d  delta= %5.3f sec\n", argv[2], kevnm, npts, delta);
wsac0(argv[2], ddummy, d, &npts, &ierr, strlen( argv[2] )) ;

  /* Check the Error status
     - 0 on Success
     - Non-Zero on Error
  */
  if(ierr != 0) {
    fprintf(stderr, "Error writing SAC File: %s\n", argv[2]);
    exit(-1);
  }
}

int usage()
{
fprintf(stderr,"Usage: axisem2sac IN_axisem OUT_sac\n");
fprintf(stderr,"       [-s STLA STLO] [-e EVLA EVLO EVDEP ] [-i CMPAZ CMPINC] [-c CMTCODE] \n");
return(-1);
}
