/*
Program to to determine the date
from a given julian day (yr/mo/day]:
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, space0, sw;
    int       year, jday, mo, day;
    int       Numday[12];
    int       i, j, k, n, sslen;


if (argc != 2) usage(-1);
sscanf( argv[1],"%4d%3d", &year, &jday );

if (! jday2dat(year,jday,&mo,&day) )
  exit (-1);

fprintf(stdout, "%4d %d %d\n", year, mo, day);

}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: datjul YYYYJJJ\n");
   exit( exitstatus );
}

