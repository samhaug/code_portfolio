/*
 * colmerge - merges the columns of file1 and file2
   MAXIMUM OF 6 FILES, for now!
 *
 */

#include <stdio.h>
#include <string.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, space0, sw;
    int       field[50], begch[50], endch[50];
    int       i, j, k, n, nfiles;
    char      s0[80], s1[80], s2[80], s3[80], s4[80], s5[80];
    char      kfiles[30][30];
    
    FILE     *fp0, *fp1, *fp2, *fp3, *fp4, *fp5;


if (argc < 3) {
     fprintf( stderr, "usage: colmerge -s file1 file2 ... \n");
     exit( -1 );
}
while ( ++index < argc && argv[index][0] == '-' ) {
     switch ( argv[index][1] ) {
         case 's':
             index++;
             while(index<argc) {
                sprintf(kfiles[j], "%s", argv[index]);
                if (kfiles[j][4] == ' ') kfiles[j][4] = '\0';
                if (kfiles[j][3] == ' ') kfiles[j][3] = '\0';
                index++;
                j++;
             }
             nfiles = argc - 2;
             break;
         default:
             fprintf( stderr, "usage: colmerge -s file1 file2 ... \n");
             exit( -1 );
     }
}

if (nfiles > 6) {
  fprintf( stderr, "No more than 6 files ... \n");
  exit( -1 );
}
for(i=0; i<nfiles; ++i) {
   if (i==0) fp0 = fopen(kfiles[0],"r");
   if (i==1) fp1 = fopen(kfiles[1],"r");
   if (i==2) fp2 = fopen(kfiles[2],"r");
   if (i==3) fp3 = fopen(kfiles[3],"r");
   if (i==4) fp4 = fopen(kfiles[4],"r");
   if (i==5) fp5 = fopen(kfiles[5],"r");
}
   while (fgets(s0,80,fp0) != NULL ) {
       k = strlen(s0); s0[k-1] = '\0';
       fprintf(stdout,"%s", s0);
       for(i=1; i<nfiles; ++i) {
          if       (i==1) {
            fgets(s1,80, fp1);
            k = strlen(s1); s1[k-1] = '\0';
            if (i == (nfiles-1)) {
              fprintf(stdout," %s\n", s1);
            } else {
              fprintf(stdout," %s", s1);
            }
          } else if (i==2) {
            fgets(s2,80, fp2);
            k = strlen(s2); s2[k-1] = '\0';
            if (i == (nfiles-1)) {
              fprintf(stdout," %s\n", s2);
            } else {
              fprintf(stdout," %s", s2);
            }
          } else if (i==3) {
            fgets(s3,80, fp3);
            k = strlen(s3); s3[k-1] = '\0';
            if (i == (nfiles-1)) {
              fprintf(stdout," %s\n", s3);
            } else {
              fprintf(stdout," %s", s3);
            }
          } else if (i==4) {
            fgets(s4,80, fp4);
            k = strlen(s4); s4[k-1] = '\0';
            if (i == (nfiles-1)) {
              fprintf(stdout," %s\n", s4);
            } else {
              fprintf(stdout," %s", s4);
            }
          } else if (i==5) {
            fgets(s5,80, fp5);
            k = strlen(s5); s5[k-1] = '\0';
            if (i == (nfiles-1)) {
              fprintf(stdout," %s\n", s5);
            } else {
              fprintf(stdout," %s", s5);
            }

          }
       }
    }

exit( 0 );
}
