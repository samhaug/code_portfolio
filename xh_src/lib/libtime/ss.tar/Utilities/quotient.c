#include <stdlib.h>
#include <stdio.h>
#include <string.h>


// The  div() function computes the value numer/denom and returns
// the quotient and remainder in a structure named div_t that
// contains two integer members named quot and rem.
 
// RETURN VALUE: div_t structure.
 
void usage();

main( argc, argv )
int   argc;
char *argv[];
{

int i1,i2;
div_t d;
if (argc !=3) usage(-1);

sscanf(argv[1],"%d", &i1);
sscanf(argv[2],"%d", &i2);

d = div(i1,i2);

fprintf(stdout,"%d %d\n",d.quot,d.rem);

exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: quotient I1 I2\n"); 
   exit( exitstatus );
}

