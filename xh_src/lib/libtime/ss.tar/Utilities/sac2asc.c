#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <math.h>

#define MAXPOINTS 262144
#define NSTA      11

#define SAC_STRING_LENGTH   -1


int main(argc,argv)
int argc;
char *argv[];
{

float   d[MAXPOINTS];
float   b, delta;
// time segment to be written written
// full segment (i=0,1, ..., npts-1) if w1=w2=-999.;
float   w1=-999., w2=-999.;

int     max = MAXPOINTS-1;
int     npts;
int     i_header=0; // do not write the header if =0
int     i_time=0;   // do not write the times (i.e. x-axis)
int     index, i;
int     i1, i2; // integers for (w1-b)/delta and (w2-b)/delta
int     ierr;

FILE   *ofl, *fopen();

int usage();
void rsac1();


if (argc < 3) {
  ierr = usage();
  exit(ierr);
}
index = 2;
while ( ++index < argc && argv[index][0] == '-' ) {
  switch ( argv[index][1] ) {
     // i_header = 1 --> print header
     case 'h':
            i_header = 1;
        break;
     case 't':
            i_time = 1;
        break;
     // time window
     case 'w':
        if ( sscanf( argv[++index], "%f", &w1 ) != 1) {
            ierr = usage();
        }
        if ( sscanf( argv[++index], "%f", &w2 ) != 1) {
            ierr = usage();
        }
        break;
     default:
        ierr = usage();
        exit(ierr);
  }
}

// reading sac file
rsac1( argv[1], d, &npts, &b, &delta, &max, &ierr, strlen( argv[1] ) ) ;
if ( ierr != 0 || npts>(MAXPOINTS-1) || max>(MAXPOINTS-1) ){
      fprintf(stderr,"Error reading in SAC file: %s ierr= %d max= %d npts= %d\n", argv[1], ierr, max, npts);
      fprintf(stderr,"Exiting ...\n");
      exit(ierr);
}

ofl = fopen(argv[2],"w");
if (i_header == 1) {
  fprintf(ofl,  "npts= %d  delta= %5.3f sec\n", npts, delta);
}
fprintf(stdout,"Ascii %s npts= %d  delta= %5.3f sec\n", argv[2], npts, delta);
if ( fabs(w1+999.)<0.001 && fabs(w2+999.)<0.001 ) {
  for(i=0; i< npts;i++) {
    if (i_time == 1) {
      fprintf(ofl,"%8.3f %10.3e\n", b+i*delta, d[i]);
    } else { 
      fprintf(ofl,"%10.3e\n", d[i]);
    }
  }
} else {
  i1 = (int) lrintf((w1-b)/delta);
  i2 = (int) lrintf((w2-b)/delta);
  if ( i1<0 || i1>npts-1 ) {
    fprintf(stderr,"i1= %d is < 0 or > npts= %d\n", i1, npts);
    fprintf(stderr,"Exiting ...\n");
    exit(-1);
  }
  if ( i2<0 || i2>npts-1 ) {
    fprintf(stderr,"i2= %d is < 0 or > npts= %d\n", i2, npts);
    fprintf(stderr,"Exiting ...\n");
    exit(-1);
  }
  for(i=i1; i<i2;i++) {
    if (i_time == 1) {
      fprintf(ofl,"%8.3f %10.3e\n", b+i*delta, d[i]);
    } else { 
      fprintf(ofl,"%10.3e\n", d[i]);
    }
  }
}

}

int usage()
{
fprintf(stderr,"Usage: sac2asc IN_sac OUT_asc ");
fprintf(stderr,"[-h] [-t] [-w w1 w2]\n");
return(-1);
}
