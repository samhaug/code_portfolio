#include <stdio.h>
#include <stdlib.h>
#include <math.h>


void usage();

main( argc, argv )
int   argc;
char       *argv[];

{

int       year, mo, day, jday;
int       err;

if (argc != 4) usage(-1);

sscanf(argv[1], "%d", &year );
sscanf(argv[2], "%d", &mo );
sscanf(argv[3], "%d", &day );

err = dat2jday(year, mo, day, &jday);

fprintf(stdout,"%4d %03d\n", year, jday);

}


int dat2jday(yr, mo, day, jday)
int     yr, mo, day, *jday;
{

/* days in the month */
static int      dim[2][13] = {
        {0,31,28,31,30,31,30,31,31,30,31,30,31},
        {0,31,29,31,30,31,30,31,31,30,31,30,31}, };
/* accumulated number of days in the month */
static int      eom[2][13] = {
        {0,31,59,90,120,151,181,212,243,273,304,334,365},
        {0,31,60,91,121,152,182,213,244,274,305,335,366}, };

	int k=0, l, i;

        if (yr              < 0) return(0);
        if (mo > 12  || mo  < 0) return(0);
        if (day > 31 || day < 0) return(0);
        k=isleap(yr);

        *jday = eom[k][mo-1]; 
        *jday = *jday + day;

        if (*jday > 366) return(0);
        return(1);
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: dat2jday YEAR MONTH DAY\n");
   exit( exitstatus );
}

