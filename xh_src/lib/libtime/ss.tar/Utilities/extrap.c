// extrap - reads in a x-y file and reads x0 from stdin
// and printf the y-value after extrapolation

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j, nlines;
    char      ss[120];
    float     x[90000], y[90000];
    float a,b;
    float     x0;


   if (argc < 3) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'x':
                if ( sscanf( argv[++index], "%f", &x0 ) != 1) usage (-1);
                break;
            default:
                usage(-1);
        }
   }

   i=0;
   while ( fgets(ss,120,stdin) != NULL ) {
      sscanf(ss,"%f %f", &x[i], &y[i]);
      i++;
   }
   nlines = i;
   i = linefit(x,y,nlines,&a,&b);
   fprintf(stdout,"%f %f\n",x0,a*x0 + b);
   exit( 0 );
}

int linefit(x,y,nlines,a,b)
    float     x[90000], y[90000];
    int nlines;
    float *a; // a= direction coefficient
    float *b; // b= intercept
{

int i,j;
float ata[2][2];
float atainv[2][2];
float aty[2];
float disc;

for(i=0;i<2;i++) {
  aty[i]=0.;
  for(j=0;j<2;j++) {
    ata[i][j]=0.;
    atainv[i][j]=0.;
  }
}

for(i=0;i<nlines;i++) {
  ata[0][0]=ata[0][0] + x[i]*x[i];
  ata[0][1]=ata[0][1] + x[i];
  ata[1][0]=ata[1][0] + x[i];
  ata[1][1]=ata[1][1] + 1.;
}
disc = ata[0][0]*ata[1][1] - ata[0][1]*ata[1][0];

atainv[0][0] =  ata[1][1]/disc; 
atainv[1][1] =  ata[0][0]/disc; 
atainv[0][1] = -ata[1][0]/disc; 
atainv[1][0] = -ata[0][1]/disc; 

for(i=0;i<nlines;i++) {
  aty[0] = aty[0] + x[i]*y[i]; 
  aty[1] = aty[1] + y[i];
}

*a = atainv[0][0]*aty[0] + atainv[0][1]*aty[1]; 
*b = atainv[1][0]*aty[0] + atainv[1][1]*aty[1]; 


return(1);
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: extrap -x x0 \n"); 
   exit( exitstatus );
}


