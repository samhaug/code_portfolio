/*
 * dlnVsVp - reads in file with 3 columns;
   x,y, z1 and
   x,y, z2
   
   First, it sets z2 = 2*z2
   then it writes 
   x,y  2 * z1*z2/( z1*z1 + z2*z2 )
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    int       colnum, nlines;
    char      ss1[120], ss2[120], in1[30], in2[30];
    double    x, y, z1, z2;
    float     tmin = 0.;
    FILE     *f1, *f2, *fopen();


   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case '1':
                if ( sscanf( argv[++index], "%s", in1 ) != 1) usage (-1);
                break;
            case '2':
                if ( sscanf( argv[++index], "%s", in2 ) != 1) usage (-1);
                break;
            case 't':
                if ( sscanf( argv[++index], "%f", &tmin ) != 1) usage (-1);
                break;
            default:
                usage(-1);
        }
   }

   f1 = fopen(in1,"r");
   f2 = fopen(in2,"r");
   i=0;
   while ( fgets(ss1,120,f1) != NULL ) {
      fgets(ss2,120,f2);
      sscanf(ss1,"%lf %lf %lf", &x, &y, &z1);
      sscanf(ss2,"%lf %lf %lf", &x, &y, &z2);
      z2 = z2*2.;
/*
      if (z1 == 0. || z2 == 0.) {
        fprintf(stdout,"%lf %lf %lf\n", x, y, -1.);
      } else {
        fprintf(stdout,"%lf %lf %lf\n", x, y, -1. + 2.*z1*z2/(z1*z1 + z2*z2));
      }
*/
      if (z1*z2 < 0. &&  fabs(z1) > tmin) {
        fprintf(stdout,"%lf %lf %lf\n", x, y, 2.*z1*z2/(z1*z1 + z2*z2));
      }
   }

   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: norm3 -n column [column <= 3] \n"); 
   exit( exitstatus );
}

