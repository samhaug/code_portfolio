/*
 * abs3 - reads in lat/lon file with 2 columns and outputs lat lon
           where lon = [-180,180] (option 0) or [0,360] (option 1)
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    int       lonopt, nlines;
    char      ss[120];
    double    lat, lon;
    double    max;


   if (argc < 3) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'n':
                if ( sscanf( argv[++index], "%d", &lonopt ) != 1) usage (-1);
                if ( lonopt > 1 ) usage (-1);
                break;
            default:
                usage(-1);
        }
   }

   while ( fgets(ss,120,stdin) != NULL ) {
      sscanf(ss,"%lf %lf", &lon, &lat);
      if        (lonopt == 0) {
         if (lon > 180.) {
           fprintf(stdout,"%lf %lf\n", lon - 360., lat);
         } else {
           fprintf(stdout,"%lf %lf\n", lon, lat);
         }
      } else if (lonopt == 1) {
         if (lon < 0.) {
           fprintf(stdout,"%lf %lf\n", lon + 360., lat);
         } else {
           fprintf(stdout,"%lf %lf\n", lon, lat);
         }
      }
   } 
   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: fixlon -n 1 or 2  option 0: -180,180    option 1: 0,360\n"); 
   exit( exitstatus );
}

