#include <stdio.h>
#include <stdlib.h>
#include <math.h>

main(argc, argv)
int   argc;
char *argv[];
{
float moment, mw;

if (argc != 2) {
          printf("Usage: Mw magnitude\n");
          printf("       Returns: M0 in dyn.cm\n");
          exit(1);
        } else {
          mw  = atof(argv[1]);
        }

//fprintf(stdout,"MW= %f\n", mw);
moment = 0.;
moment = mw + 10.73;
// fprintf(stdout,"M0= %e\n", moment);
moment = 1.5 * moment;
// fprintf(stdout,"M0= %e\n", moment);
moment = pow(10., moment);

fprintf(stdout,"M0= %6.2e\n", moment);
}
