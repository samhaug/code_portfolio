/*
 * chstrp - displays all characters between $2 and $3 of a character string
   e.g., 

  prompt> echo abcdefgh | chstrp -f 3 7  
         produces  "defg"
  prompt> 
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void usage();

int main( argc, argv )
int   argc;
char       *argv[];
{
int       index = 0, i, field1, field2;
char      ss[120];


if (argc < 4) usage(-1);

while ( ++index < argc && argv[index][0] == '-' ) {
   switch ( argv[index][1] ) {
     case 'f':
       if ( sscanf( argv[++index], "%d", &field1 ) != 1 ||
            sscanf( argv[++index], "%d", &field2 ) != 1) usage(-1);
       break;
   default:
       usage(-1);
   }
}
if (field1 > field2) usage (-1);

while (fgets(ss,120,stdin) != NULL ) {

   for(i=field1-1; i<field2; ++i) {
     if (ss[i] == '\0') goto done;
     putc(ss[i],stdout);
   }
   done:
   fprintf(stdout,"\n");
}

exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: chstrp -f field1 field2\n"); 
   exit( exitstatus );
}

