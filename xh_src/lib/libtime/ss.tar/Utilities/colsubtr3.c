/*
 * colsubtrct3 - reads in two files with 3 columns and
   subtract the nth (1, 2 or 3) column of file 1 from the
   nth column of file 2.
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    int       colnum;
    char      ss[120], file1[80], file2[80];
    double    x1,y1,z1;
    double    x2,y2,z2;
    FILE *fp1, *fp2, *fopen();


   if (argc < 3) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case '1':
                if ( sscanf( argv[++index], "%s", file1 ) != 1) usage (-1);
                break;
            case '2':
                if ( sscanf( argv[++index], "%s", file2 ) != 1) usage (-1);
                break;
            case 'c':
                if ( sscanf( argv[++index], "%d", &colnum ) != 1) usage (-1);
                if ( colnum > 3 ) usage (-1);
                break;
            default:
                usage(-1);
        }
   }
   fp1 = fopen(file1,"r");
   fp2 = fopen(file2,"r");
   

   if        (colnum == 3) {
     while ( fgets(ss,120,fp1) != NULL ) {
        sscanf(ss,"%lf %lf %lf", &x1, &y1, &z1);
        fgets(ss,120,fp2);
        sscanf(ss,"%lf %lf %lf", &x2, &y2, &z2);
        if (x1 == x2 && y1 == y2) {
        /* add hoc addition: */
          if (z1 == 0.) z2 = 0.;
          if (z2 == 0.) z1 = 0.;
          fprintf(stdout,"%lf %lf %lf\n", x1, y1, z1-z2);
        } else {
          fprintf(stderr,"x1 is not equal to y1 ..\n");
          exit (-1);
        }
     }
   } else if (colnum == 2) {
     while ( fgets(ss,120,stdin) != NULL ) {
        sscanf(ss,"%lf %lf %lf", &x1, &y1, &z1);
        fgets(ss,120,fp2);
        sscanf(ss,"%lf %lf %lf", &x2, &y2, &z2);
        if (x1 == x2 && z1 == z2) {
          fprintf(stdout,"%lf %lf %lf\n", x1, y1-y2, z1);
        } else {
          fprintf(stderr,"x1 is not equal to y1 ..\n");
          exit (-1);
        }
     }
   } else if (colnum == 1) {
     while ( fgets(ss,120,stdin) != NULL ) {
        sscanf(ss,"%lf %lf %lf", &x1, &y1, &z1);
        fgets(ss,120,fp2);
        sscanf(ss,"%lf %lf %lf", &x2, &y2, &z2);
        if (y1 == y2 && z1 == z2) {
          fprintf(stdout,"%lf %lf %lf\n", x1-x2, y1, z1);
        } else {
          fprintf(stderr,"x1 is not equal to y1 ..\n");
          exit (-1);
        }
     }
   }

   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: colsubtrct -1 file1 -2 file2 -c [column <= 3] \n"); 
   exit( exitstatus );
}

