/*
Program to turn the IASP91.DAT into seismic profiles for FK
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

main(argc,argv)
int argc;
char **argv;
{
FILE *ifl;

int i, n_layers=0;
int k;

float thck[3000],rho[3000],vs[3000],vp[3000],qs[3000],qp[3000];
float dep[3000], newz[3000];

float thck_old, EarthRad, flat;

char ss[140];

if ((ifl = fopen(argv[1],"r")) == NULL) {
  fprintf(stderr,"%s cannot be opened ...\n", ifl);
  exit(-1);
}

EarthRad = 6371.;
thck_old = 0.;
i=0;
while ( fgets(ss,140,ifl) != NULL ) {
   sscanf(ss,"%f %f %f %f %f %f %*f", &dep[i],&vp[i],&qp[i],&vs[i],&qs[i],&rho[i]);
   flat = EarthRad/(EarthRad - dep[i]);
   vp[i] = vp[i] * flat;
   vs[i] = vs[i] * flat;
   rho[i] = rho[i] * flat;
   newz[i] = EarthRad * log(flat);
//  fprintf(stdout,"DEP= %f NEWZ= %f flat= %f\n", dep[i], newz[i], flat);
   i = i+1;
}
n_layers = i-1;

k=0;
for (i=1; i<n_layers; i++) { 
     fprintf(stdout,"%10.4f %9.4f %9.4f %9.4f %9.4f %9.4f\n",
           newz[i]-newz[i-1],vp[i],vs[i],rho[i],qp[i],qs[i]);
     k++;
}

}
