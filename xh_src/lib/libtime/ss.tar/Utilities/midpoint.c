// program to print out (lat,lon) at a
// the midpont betweeb (LAT1,LON2) and (LAT2,LON2)


// ---------------------------------------------------------------------
// Does not work for a distance exactly 90 degrees (tan is not defined).
// My quick-and-dirty fix:
// If (arc_dist == 90) arc_dist = 89.999;
// ---------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void usage( );

main(argc, argv)
int argc;
char *argv[];

{
int i, index;
float phi;
float elat, elon, slat, slon, delta, az, baz;
float xlat, xlon;

index = 0;

if (argc != 7) usage(-1);
while ( ++index < argc ) {
  if ( argv[index][0] != '-' ) usage(-1);
  switch ( argv[index][1] ) {
    case 'e':
        if ( sscanf( argv[++index], "%f", &elat ) != 1 ||
             sscanf( argv[++index], "%f", &elon ) != 1 ) usage(-1);
        break;
    case 's':
        if ( sscanf( argv[++index], "%f", &slat ) != 1 ||
             sscanf( argv[++index], "%f", &slon ) != 1 ) usage(-1);
        break;
    default:
        usage(-1);
  } // switch
} // while

if( ! distaz(elat,elon,slat,slon,&delta, &az, &baz) )
  exit(-1);
// fprintf(stdout,"delta= %f az= %f baz= %f\n", delta,az,baz);
delta = delta/2.;
if( ! distaz2latlon(elat,elon,delta,baz, &xlat, &xlon) )
  exit(-1);

if (xlon >= 180.) xlon -= 360.;
if (xlon < -180.) xlon += 360.;

fprintf(stdout,"%6.3f %7.3f\n", xlat,xlon);

}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: midpoint  -e elat elon -s slat slon\n"); 
   exit( exitstatus );
}

