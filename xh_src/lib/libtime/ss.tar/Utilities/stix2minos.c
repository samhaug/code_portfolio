// Program to turn the PYRL output from Lars into seismic profiles for MINOS
//Some assumptions:
//
// Using SOCAL for the crust
// SOCAL features a 35-km thick crust, comprised of three layers
//
//  Depth     vp      vs      rho    qp         qs
//    5.5    5.50    3.18     2.40  1000.00    500.00
//   16.0    6.30    3.64     2.67  1000.00    500.00
//   35.0    6.70    3.87     2.80  1600.00    800.00
// mantle    7.80    4.50     3.30  1600.00    800.00
//
// Below 200 km, we assume an increase from Vs(200) to Vs(moho)
// following (z-z0)**n


#include <stdio.h>
#include <stdlib.h>
#include <math.h>

main(argc,argv)
int argc;
char **argv;
{
FILE *ifl;
FILE *prem, *fopen();
char dir[80];

int i;
int k;

float dep[3000],rho[3000],vs[3000],vp[3000],qs[3000],qp[3000];
float dz, z, Pval, Sval, Rval, QSval;

float Rad = 6371000.;

int   ifanis   = 0;       // if anisotropic
float tref     = 1.;      // reference period
float Qkappa   = 57823.;  // Q kappa
float eta      = 1.;      // ETA
int   ifdeck   = 1;       // if card deck model
int   nlayers  = 166;     // number of layers
int   nic      =  33;     // index of solid side of ICB
int   noc      =  66;     // index of fluid side of CMB

float z0,z1,vp0,vp1,vs0,vs1,rh0,rh1,qs0,qs1;
float poly =    2.;	// quadratic decrease of vp, vs, rho and w from 200 km to moho

char ss[120];

if (argc != 4) {
  fprintf(stderr,"Usage: stix2minos INFILE -p POLY\n");
  exit(1);
}
if ((ifl = fopen(argv[1],"r")) == NULL) {
  fprintf(stderr,"%s cannot be opened ...\n", ifl);
  exit(-1);
}
if ( strncmp(argv[2],"-p",2) == 0) {
  sscanf(argv[3],"%f", &poly);
} else {
  fprintf(stderr,"Usage: stix2minos INFILE -p POLY\n");
  exit(1);
}

// HEADER output
fprintf(stdout,"MODEL.01\n");
fprintf(stdout,"%3d %5.1f %3d\n", ifanis, tref, ifdeck);
fprintf(stdout,"%4d %4d %4d\n", nlayers, nic, noc);

// Reading the PREM CORE
// 67 lines
sprintf(dir,"%s/%s",getenv("UTILS"),"MINOS/prem_noocean.txt");
prem = fopen(dir,"r");
for (i=0;i<67;i++) {
     fgets(ss,120,prem);
     fprintf(stdout,"%s", ss);
}
fclose(prem);

// Reading Lars' profile
i=0;
while ( fgets(ss,120,ifl) != NULL ) {
   sscanf(ss,"%*f %f %*f %f %*f %*f %*f %f %f %f %f", &dep[i],&rho[i],&vs[i],&vp[i],&qs[i],&qp[i]);
   i = i+1;
}

z  = 2850.;
while (z > 180.){
  dz = 40.;
  if (z < 1700.) dz = 40.;
  if (z < 1100.) dz = 30.;
  if (z <  850.) dz = 20.;
  if (z <  330.) dz = 20.;
  if (z <  100.) dz = 10.;
  if (z <   33.) dz =  3.;
  if (z <    5.) dz =  1.;
  z = z - dz;
  if (! interp(z, dep, vp, &Pval) ) {
     fprintf(stderr,"Error in interp() z= %f\n", z);
     exit(-1);
  }
  if (! interp(z, dep, vs, &Sval) ) {
     fprintf(stderr,"Error in interp() z= %f\n", z);
     exit(-1);
  }
  if (! interp(z, dep, rho, &Rval) ) {
     fprintf(stderr,"Error in interp() z= %f\n", z);
     exit(-1);
  }
  if (! interp(z, dep, qs, &QSval) ) {
     fprintf(stderr,"Error in interp() z= %f\n", z);
     exit(-1);
  }
  fprintf(stdout,"%7.0f. %8.2f %8.2f %8.2f %8.1f %8.1f %8.2f %8.2f %8.5f\n",
         Rad-z*1000.,Rval*1000.,Pval*1000.,Sval*1000.,Qkappa,QSval,Pval*1000.,Sval*1000.,eta);
}

// Smoothly go from z1 (last depth) to the base of the moho
// using an polynomial function

z1 = z;
vp1 = Pval;
vs1 = Sval;
rh1 = Rval;
qs1 = QSval;
dz = 20.;

z0  = 35.;
vp0 = 7.8;
vs0 = 4.5;
rh0 = 3.3;
qs0 = 800.;

while (z > 40){
  dz = 20.;
  if (z<100) {
    dz=10.;
  }
  z = z - dz;
  if (! tbl(z,z1,z0,vp1,vp0,poly,&Pval) ) {
     fprintf(stderr,"Error in tbl() z= %f\n", z);
     exit(1);
  }
  if (! tbl(z,z1,z0,vs1,vs0,poly,&Sval) ) {
     fprintf(stderr,"Error in tbl() z= %f\n", z);
     exit(1);
  }
  if (! tbl(z,z1,z0,rh1,rh0,poly,&Rval) ) {
     fprintf(stderr,"Error in tbl() z= %f\n", z);
     exit(1);
  }
  if (! tbl(z,z1,z0,qs1,qs0,poly,&QSval) ) {
     fprintf(stderr,"Error in tbl() z= %f\n", z);
     exit(1);
  }
  fprintf(stdout,"%7.0f. %8.2f %8.2f %8.2f %8.1f %8.1f %8.2f %8.2f %8.5f\n",
         Rad-z*1000.,Rval*1000.,Pval*1000.,Sval*1000.,Qkappa,QSval,Pval*1000.,Sval*1000.,eta);
}
z     = 35.0;
Pval  =  7.80;
Sval  =  4.50;
Rval  =  3.30;
QSval =  800.;
fprintf(stdout,"%7.0f. %8.2f %8.2f %8.2f %8.1f %8.1f %8.2f %8.2f %8.5f\n",
       Rad-z*1000.,Rval*1000.,Pval*1000.,Sval*1000.,Qkappa,QSval,Pval*1000.,Sval*1000.,eta);
z     = 35.0;
Pval  =  6.70;
Sval  =  3.87;
Rval  =  2.80;
QSval =  500.;
fprintf(stdout,"%7.0f. %8.2f %8.2f %8.2f %8.1f %8.1f %8.2f %8.2f %8.5f\n",
       Rad-z*1000.,Rval*1000.,Pval*1000.,Sval*1000.,Qkappa,QSval,Pval*1000.,Sval*1000.,eta);
z     = 16.0;
Pval  =  6.30;
Sval  =  3.64;
Rval  =  2.67;
QSval =  500.;
fprintf(stdout,"%7.0f. %8.2f %8.2f %8.2f %8.1f %8.1f %8.2f %8.2f %8.5f\n",
       Rad-z*1000.,Rval*1000.,Pval*1000.,Sval*1000.,Qkappa,QSval,Pval*1000.,Sval*1000.,eta);
z     =  5.5;
Pval  =  5.50;
Sval  =  3.18;
Rval  =  2.40;
QSval =  500.;
fprintf(stdout,"%7.0f. %8.2f %8.2f %8.2f %8.1f %8.1f %8.2f %8.2f %8.5f\n",
       Rad-z*1000.,Rval*1000.,Pval*1000.,Sval*1000.,Qkappa,QSval,Pval*1000.,Sval*1000.,eta);
z     =  0.0;
Pval  =  5.50;
Sval  =  3.18;
Rval  =  2.40;
QSval =  500.;
fprintf(stdout,"%7.0f. %8.2f %8.2f %8.2f %8.1f %8.1f %8.2f %8.2f %8.5f\n",
       Rad-z*1000.,Rval*1000.,Pval*1000.,Sval*1000.,Qkappa,QSval,Pval*1000.,Sval*1000.,eta);

}


int interp(z,dep,array,val)

float z;
float dep[3000];
float array[3000];
float *val;

{

int i=0;
float da, dz, dv; 

while (z > dep[i] )
   i++;

dz = dep[i] - dep[i-1];
da = array[i]-array[i-1];
dv = da/dz;

*val =  array[i-1] + (z-dep[i-1])*dv;

// fprintf(stdout,"INTERP i= %d  z= %f z1= %f z2 = %f\n", i, z,dep[i-1],dep[i]);
// fprintf(stdout,"INTERP v1= %f v2= %f val=%f \n", array[i-1],array[i], *val);
}

int tbl(z,z1,z0,v1,v0,poly,val)

float z,z1,z0;
float v1,v0;
float poly;
float *val;

{

int i=0;
float v;

v = (z-z1)/(z0-z1);
v = powf(v, poly);
v = v1 + v*(v0-v1);

*val = v;

// fprintf(stdout,"TBL z= %f z0= %f z1= %f\n",  z,  z0,z1);
// fprintf(stdout,"TBL v= %f v0= %f v1= %f\n", *val,v0,v1);
}
