//
// norm2 -
// reads in file with 2 columns and
// normalises the nth (1 or 2) column.
// between sample i1 and i2

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    int       i1, i2;
    int       colnum, nlines;
    char      ss[120];
    double    x[10000], y[10000];
    double    xmax, ymax;


   if (argc < 3) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'n':
                if ( sscanf( argv[++index], "%d", &colnum ) != 1) usage (-1);
                if ( colnum > 2 ) usage (-1);
                break;
            case '1':
                if ( sscanf( argv[++index], "%d", &i1 ) != 1) usage (-1);
                break;
            case '2':
                if ( sscanf( argv[++index], "%d", &i2 ) != 1) usage (-1);
                break;
            default:
                usage(-1);
        }
   }

   i=0;
   if (colnum == 1) {
     xmax = 0.;
     while ( fgets(ss,120,stdin) != NULL ) {
        sscanf(ss,"%lf %lf", &x[i], &y[i]);
        if (fabs(x[i])>xmax && i>=i1 && i<=i2) {
          xmax = fabs(x[i]); 
        }
        i++;
     }
     if (xmax == 0.) xmax = 1.;
     nlines = i;
     for (i=1; i<nlines; ++i) 
       fprintf(stdout,"%lf %lf\n", x[i]/xmax, y[i]);

   } else if (colnum == 2) {
     ymax = 0.;
     while ( fgets(ss,120,stdin) != NULL ) {
        sscanf(ss,"%lf %lf", &x[i], &y[i]);
        if (fabs(y[i])>ymax && i>=i1 && i<=i2) {
          ymax = fabs(y[i]);
        }
        i++;
     }
     if (ymax == 0.) ymax = 1.;
     nlines = i;
     for (i=1; i<nlines; ++i) 
       fprintf(stdout,"%lf %lf\n", x[i], y[i]/ymax);

   } else {
     usage (-1);
   }

   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: norm2 -n column [column <= 2] -1 i1 -2 i2 [sample numbers]\n"); 
   exit( exitstatus );
}

