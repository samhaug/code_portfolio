/*
 * col2divide - reads in a file with 2 columns and
   divide the nth (1 or 2) column by fac.
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    int       colnum;
    char      ss[120], file1[80], file2[80];
    double    x1,y1, fac;
    FILE     *fp1, *fopen();


   if (argc < 3) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case '1':
                if ( sscanf( argv[++index], "%s", file1 ) != 1) usage (-1);
                break;
            case 'c':
                if ( sscanf( argv[++index], "%d", &colnum ) != 1) usage (-1);
                if ( colnum > 2 ) usage (-1);
                break;
            case 'x':
                if ( sscanf( argv[++index], "%lf", &fac ) != 1) usage (-1);
                if ( fac == 0. ) usage (-1);
                break;
            default:
                usage(-1);
        }
   }
   fp1 = fopen(file1,"r");
   

   while ( fgets(ss,120,fp1) != NULL ) {
      sscanf(ss,"%lf %lf", &x1, &y1);
      if        (colnum == 2) {
        fprintf(stdout,"%lf %lf\n", x1, y1/fac);
      } else if (colnum == 1) {
        fprintf(stdout,"%lf %lf\n", x1/fac, y1);
      }
   }
   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: coladd2 -1 file1 -c [column <= 2] -x fac\n"); 
   fprintf(stderr,"\n");
   fprintf(stderr,"Reads in a file with 2 columns and\n");
   fprintf(stderr,"divide the nth (1 or 2) column by fac.\n");
   exit( exitstatus );
}

