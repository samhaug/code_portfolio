/*
 * gradient - calculate the gradient (dy/dx) of an 
              x-y file and multiplies it by fac
 *
 */

#include <stdio.h>
#include <string.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index;
    int       i, j, numpoints;
    double    fac, grad=0.;
    double    x[1000], y[1000];
    char      ss[120], flnm[30];
    FILE      *fp;


   if (argc < 3) usage(-1);
   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'f':
                if ( sscanf( argv[++index], "%lf", &fac ) != 1) usage(-1);
                break;
            case 'o':
                if ( sscanf( argv[++index], "%s", flnm ) != 1) usage(-1);
                break;
            default:
                usage(-1);
        }
   }
   fp = fopen(flnm,"r");

   i=0;
   while ( fgets(ss,120,fp) != NULL ) {
      sscanf(ss,"%lf %lf", &x[i], &y[i]);
      ++i;
   }
   numpoints=i-30;

   for(j=30;j<numpoints;++j) {
      grad = (y[j+30] - y[j-30])/(x[j+30] - x[j-30]);
      grad = grad*fac;
      fprintf(stdout, "%lf %lf\n", x[j], grad);
   }



exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: gradient -f fac -o inputfile\n"); 
   exit( exitstatus );
}

