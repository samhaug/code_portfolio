/*
 * subfromcol3 - reads in file with 3 columns and subtract X from the nth (1,2,3) column.
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0;
    int       colnum;
    char      ss[120], file[80];
    double    a1,a2,a3,x;


   if (argc < 3) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'x':
                if ( sscanf( argv[++index], "%lf", &x ) != 1) usage (-1);
                break;
            case 'c':
                if ( sscanf( argv[++index], "%d", &colnum ) != 1) usage (-1);
                if ( colnum > 3 ) usage (-1);
                break;
            default:
                usage(-1);
        }
   }
   

   if        (colnum == 3) {
     while ( fgets(ss,120,stdin) != NULL ) {
        sscanf(ss,"%lf %lf %lf", &a1, &a2, &a3);
        fprintf(stdout,"%lf %lf %lf\n", a1, a2, a3-x);
     }
   } else if (colnum == 2) {
     while ( fgets(ss,120,stdin) != NULL ) {
        sscanf(ss,"%lf %lf %lf", &a1, &a2, &a3);
        fprintf(stdout,"%lf %lf %lf\n", a1, a2-x, a3);
     }
   } else if (colnum == 1) {
     while ( fgets(ss,120,stdin) != NULL ) {
        sscanf(ss,"%lf %lf %lf", &a1, &a2, &a3);
        fprintf(stdout,"%lf %lf %lf\n", a1-x, a2, a3);
     }
   }

   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: subfromcol3 -x X -c [column <= 3] \n"); 
   exit( exitstatus );
}

