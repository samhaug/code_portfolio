#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "/work/jeroen/inc/sac.h"


main(int argc, char* argv[])
{
   FILE *sacfile;
   FILE *out_file;
   struct sac_header head;
   char Record[80];

/*  Retrieving command line input: */
   if (argc != 2) {
      (void) printf("Usage: %s Record\n",argv[0]);
      return 1;
   } else {
      (void) strcpy(Record ,&argv[1][0]);
   }

/* Read sac header: */
   sacfile = fopen(Record,"r");
   (void) fread(&head, 1 , sizeof(head), sacfile);
   (void) fclose(sacfile);

/* Output: */
   out_file = fopen("out.readheader","w");

   fprintf(out_file,"EvLat= %7.2f\n", head.evla);
   fprintf(out_file,"EvLon= %8.2f\n", head.evlo);
   fprintf(out_file,"EvDep= %8.2f\n", head.evdp);
   fprintf(out_file,"StLat= %7.2f\n", head.stla);
   fprintf(out_file,"StLon= %8.2f\n", head.stlo);
   fprintf(out_file,"Gcarc= %7.2f\n", head.gcarc);
   fprintf(out_file,"Baz=   %7.2f\n", head.baz);
   fprintf(out_file,"T0=    %8.2f\n", head.t0);
   fprintf(out_file,"T1=    %8.2f\n", head.t1);

   fclose(out_file);

exit(0);

}
