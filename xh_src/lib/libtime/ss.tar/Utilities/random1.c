//     This program prints 1 if
//     the output from RAN3() is less than fract,
//     else 0

#include <stdio.h>
#include <string.h>
#include <math.h>
                                                                         
void usage();
                                                                         
main( argc, argv )
int   argc;
char       *argv[];
{
    char      ss[120];
    float r1,r2,r3,r4, fract;
    int i_null=0;
    int i_one =1;
    int n=0;
                                                                         
                                                                         
if (argc != 2) usage(-1);
                                                                         
sscanf(argv[1],"%f", &fract);
fprintf(stdout,"fract= %f\n", fract);
fprintf(stdout,"n= %d\n", n);
r1=ran1(&n);
fprintf(stdout,"r1= %f r2= %f r3= %f r4= %f n= %d\n",r1,r2,r3,r4,n);
if (r1 < fract) {
    fprintf(stdout,"%d\n", i_one);
} else {
    fprintf(stdout,"%d\n", i_null);
}

}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: random FRACT\n");
   exit( exitstatus );
}
