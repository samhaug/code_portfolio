/*
 * col2sub - reads in 1 file with 2 columns and smooth the 2nd column
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j, k;
    int       nsmth, nsmth2;
    int       max, n, colnum;
    char      ss[120], file[80];
    double    x1[10000],y1[10000], avg;
    FILE *fp, *fopen();


   if (argc < 2) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'f':
                if ( sscanf( argv[++index], "%s", file ) != 1) usage (-1);
                break;
            case 's':
                if ( sscanf( argv[++index], "%d", &nsmth ) != 1) usage (-1);
                break;
            default:
                usage(-1);
        }
   }
   nsmth2 = nsmth/2;
   fp = fopen(file,"r");
   
   for(i=0; i<10000; i++) {
    if ( fgets(ss,120,fp) != NULL ) {
       sscanf(ss,"%lf %lf", &x1[i], &y1[i]);
    } else {
      break;
    }
   }
   n = i;
   max = n/nsmth;
   for (j=0;j<max;j++) {
     avg = 0.;
     k = j*nsmth;
     for (i=k; i<k+nsmth; i++) {
        avg = avg + y1[i];
 /*       fprintf(stdout,"%lf\n", avg); */
     }
     fprintf(stdout,"%lf %lf\n", x1[nsmth2+k], avg/nsmth);
   }

   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: col2smooth -f file\n"); 
   exit( exitstatus );
}

