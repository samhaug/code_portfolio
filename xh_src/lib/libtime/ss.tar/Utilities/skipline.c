//-------------------------------------------------------------
//
//  skipline
//
// skips iskip lines ...
//
//
//-------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       linenumber = 0, index = 0, iskip;
    char      ss[180];


   if (argc != 3) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'l':
                if ( sscanf( argv[++index], "%d", &iskip ) != 1 ) usage(-1);
                break;
            default:
                usage(-1);
        }
   }

   linenumber = 0;
//  fprintf(stdout,"I_SKIP= %d linenumber= %d\n", iskip, linenumber); 
   while ( fgets(ss,180,stdin) != NULL ) {
      if (linenumber == iskip ) {
         fputs(ss,stdout);
         linenumber = 0;
      } else {
        linenumber++;
      }
   }

exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: skipline -l I_SKIP]\n"); 
   exit( exitstatus );
}

