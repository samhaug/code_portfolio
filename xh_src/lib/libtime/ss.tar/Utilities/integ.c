//
// integ -
// reads in curve (x,y file) and find:
// (1) maximum value for y and corresponding value of x 
// (2) surface area under y(x), called A.
// (3) x1, and x2 around the maximum value of y for which the
//     surface area under y(x) is pctg% of the total surface area A.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    int       imax = 0, nlines = 0;
    char      ss[120];
    double    x[10000], y[10000], dx, dy, dxdy;
    double    A, xmax, ymax, area, surfarea;
    int       pctg;


   if (argc < 3) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'x':
                if ( sscanf( argv[++index], "%d", &pctg ) != 1) usage (-1);
                break;
            default:
                usage(-1);
        }
   }

   i=0;
   ymax = -1.e10;
   while ( fgets(ss,120,stdin) != NULL ) {
      sscanf(ss,"%lf %lf", &x[i], &y[i]);
      if (y[i] > ymax) {
        ymax = y[i]; 
        xmax = x[i]; 
        imax = i; 
      }
      i++;
   }
   nlines = i;

   A = 0.;
/*
   fprintf(stdout,"Surface Area = %lf\n", A);
*/
   for (i=1; i<nlines; ++i) {
     dx =  x[i] - x[i-1];
     dy = (y[i] + y[i-1])/2.;
     if (dy < 0.) dy = -1.* dy;
     A  =  A + dx*dy;
/*
     fprintf(stdout,"x= %lf y= %lf Surface Area = %lf\n", x[i], y[i], A);
*/
   }
/*
   fprintf(stdout,"imax= %d, xmax= %lf ymax= %lf\n", imax, xmax, ymax);
*/


   i = 1;
   area = 0.;
   surfarea = A*pctg/100.;
   while (area < surfarea) {
     area = 0.;
     for (j=imax-i+1; j<imax+i+1; ++j) {
       dx =  x[j] - x[j-1];
       dy = (y[j] + y[j-1])/2.;
       if (dy < 0.) dy = -1.* dy;
       area  =  area + dx*dy;
     }
     i++;
   }
   fprintf(stdout,"%lf %lf\n", x[imax-i], 0.); 
   for (j=imax-i; j<imax+i+1; ++j) {
     fprintf(stdout,"%lf %lf\n", x[j], y[j]); 
   }
   fprintf(stdout,"%lf %lf\n", x[imax+i], 0.); 
   fprintf(stdout,"%lf %lf\n", x[imax-i], 0.); 
/*
   fprintf(stdout,"MaxValue= %lf for x= %lf\n", ymax, xmax); 
   fprintf(stdout,"TotalSurfaceArea= %lf\n", A);
   fprintf(stdout,"AreaOf_%d_pctAroundPeakY= %lf %lf\n", pctg, x[imax-i], x[imax+i]);
*/
      
     


   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: integ -x pctg\n"); 
   exit( exitstatus );
}

