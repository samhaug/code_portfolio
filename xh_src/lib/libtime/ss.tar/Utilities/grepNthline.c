/*
 * linecut - cuts out lines $1 to $2 from input file
 *
 */

#include <stdio.h>
#include <string.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       linenumber = 0, index = 0, line1, line2;
    char      ss[120];


   if (argc < 4) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'l':
                if ( sscanf( argv[++index], "%d", &line1 ) != 1 ||
                     sscanf( argv[++index], "%d", &line2 ) != 1) usage(-1);
                break;
            default:
                usage(-1);
        }
   }

   linenumber = 1;
   while ( fgets(ss,120,stdin) != NULL ) {
      if (linenumber < line1 || linenumber > line2) {
         fputs(ss,stdout);
      }
      linenumber++;
   }

exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: linecut -l line1 line2]\n"); 
   exit( exitstatus );
}

