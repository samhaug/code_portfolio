
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    float    avg = 0.;
    float  value[400000];
    float  mn;
    float  mx;
    float  sig = 0.;
    int    i = 0;
    int    i_mn, i_mx;
    int    n = 0;
    char   ss[120];


   if (argc > 1) usage(-1);

   n=0;
   i_mn = 0;
   i_mx = 0;
   while ( fgets(ss,120,stdin) != NULL ) {
      sscanf(ss,"%f", &value[n]);
      if (n == 0) {
         mn = value[0];
         mx = value[0];
      } else {
        if (value[n] < mn) {
           mn = value[n];
           i_mn = n;
        }
        if (value[n] > mx) {
           mx = value[n];
           i_mx = n;
        }
      }
      avg += value[n];
      n++;
   }
   avg = avg/n;
   sig = 0.;
   for(i=0; i<n; ++i) {
     sig = sig + (value[i] - avg)*(value[i] - avg);
   }
   sig = sig/n;

fprintf(stdout,"MinVal= %f index= %d MaxVal= %f index= %d Avg= %f Sigma= %f 2Sigma= %f\n",mn,i_mn+1,mx,i_mx+1,avg,sig,2*sig);

exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: avg\n"); 
   exit( exitstatus );
}

