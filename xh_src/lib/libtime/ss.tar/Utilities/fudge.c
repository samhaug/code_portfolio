
#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    double    x1,y1, fac;
    FILE     *fp1, *fopen();
    char      ss[120];


   fp1 = fopen(argv[1],"r");
   
   while ( fgets(ss,120,fp1) != NULL ) {
      sscanf(ss,"%lf %lf", &x1, &y1);
      if        (x1 > -260. && x1 < -235. ) { 
        fac = 1. + 0.3* fabsf( (x1 + 260)/25.);
      } else if        (x1 >= -235. && x1 < -210. ) { 
        fac = 1. + 0.3* fabsf( (x1 + 210)/25.);
      } else {
        fac = 1.;
      }
      fprintf(stdout,"%lf %lf\n", x1, fac*y1);
   }
   exit( 0 );
}
