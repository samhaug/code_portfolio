/*
 * t-d-reduc - take time (T), distance (D) and prints out
              T - D/Vred, D
              given a reduction velocity of Vred
 *
 */

#include <stdio.h>
#include <string.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index;
    int       i, deg=0;
    double    Vr=0., time, dist, l;
    char      ss[120];
    FILE      *fopen;


   if (argc < 5) usage(-1);
   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'v':
                if ( sscanf( argv[++index], "%lf", &Vr ) != 1) usage(-1);
                break;
            case 'd':
                if ( sscanf( argv[++index], "%d",  &deg ) != 1) usage(-1);
                break;
            default:
                usage(-1);
        }
   }
   while ( fgets(ss,120,stdin) != NULL ) {
      sscanf(ss,"%lf %lf", &dist, &time);
      if (deg == 1) {
        l = dist * 111.195;
      } else {
        l = dist;
      }
      if (Vr == 0.) {
        fprintf(stdout, "%8.2f %8.2f\n", dist, time);
      } else {
        fprintf(stdout, "%8.2f %8.2f\n", dist, time-l/Vr);
      }
   }

exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: t-r_reduc -v Vr -d 1=deg or 0=km\n"); 
   fprintf(stderr,"Time-Dist after velocity reduction\n"); 
   exit( exitstatus );
}

