#include <stdio.h>
#include <stdlib.h>
#include <math.h>

main(argc, argv)
int   argc;
char *argv[];
{
float moment;

if (argc != 2) {
          printf("Usage: Mw moment [in dyn.cm]\n");
          printf("       Returns: Mo --> Mw\n");
          exit(1);
        } else {
          moment  = atof(argv[1]);
        }

// moment *= 1.0e-26;
//fprintf(stdout,"Mw= %5.3f\n", log10(moment)/1.5  - 10.73);
fprintf(stdout,"%5.3f\n", log10(moment)/1.5  - 10.73);
}
