/*
 * col1order - reads in a file with 2 columns and
   places the lines in order of the values of the first column
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, numlines;
    int       out_of_order;
    char      ss[120], file1[80];
    double    x1[1000],y1[1000];
    double    x2[1000],y2[1000];
    FILE     *fp1, *fopen();


if (argc != 3) usage(-1);

while ( ++index < argc && argv[index][0] == '-' ) {
     switch ( argv[index][1] ) {
         case '1':
             if ( sscanf( argv[++index], "%s", file1 ) != 1) usage (-1);
             break;
         default:
             usage(-1);
     }
}
fp1 = fopen(file1,"r");

i=0;
while ( fgets(ss,120,fp1) != NULL ) {
  sscanf(ss,"%lf %lf", &x1[i], &y1[i]);
  x2[i]=x1[i];
  y2[i]=y1[i];
  i++;
}
numlines = i;
//fprintf(stdout,"numlines= %d\n", numlines);

out_of_order = 1;
while (out_of_order) {
  // Round 1
  for (i=0; i<numlines-1; i=i+2) {
    if (x1[i]>x1[i+1]) { 
      x2[i+1] = x1[i]; 
      y2[i+1] = y1[i]; 
      x2[i]   = x1[i+1]; 
      y2[i]   = y1[i+1]; 
    }
  }
  for (i=0; i<numlines; i++) {
    x1[i]=x2[i];
    y1[i]=y2[i];
  }
//for (i=0; i<numlines; i++) {
//  fprintf(stdout,"a1 i= %d x1= %f y1= %f\n", i,x1[i],y1[i]);
//}

  // Round 2
  for (i=1; i<numlines-1; i=i+2) {
    if (x1[i]>x1[i+1]) { 
      x2[i+1] = x1[i]; 
      y2[i+1] = y1[i]; 
      x2[i]   = x1[i+1]; 
      y2[i]   = y1[i+1]; 
    }
  }
  for (i=0; i<numlines; i++) {
    x1[i]=x2[i];
    y1[i]=y2[i];
  }
//for (i=0; i<numlines; i++) {
//  fprintf(stdout,"a2 i= %d x1= %f y1= %f\n", i,x1[i],y1[i]);
//}
  out_of_order = 0;
  for (i=0; i<numlines-1; i++) {
    if (x1[i] > x1[i+1]) out_of_order = 1;
  }

}
for (i=0; i<numlines; i++) {
  fprintf(stdout,"%f %f\n", x1[i],y1[i]);
}


exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: col2order -1 file1 -c [column <= 2]\n"); 
   fprintf(stderr,"\n");
   fprintf(stderr,"Reads in a file with 2 columns and\n");
   fprintf(stderr,"puts them in order according to the nth (1 or 2) column.\n");
   exit( exitstatus );
}

