/*
 * newcol - reads in a file with 2 columns and adds a third column
   with a value X
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    int       colnum;
    char      ss[120], file[80];
    double    x1,y1,X;
    FILE *fp, *fopen();


   if (argc < 4) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'f':
                if ( sscanf( argv[++index], "%s", file ) != 1) usage (-1);
                break;
            case 'x':
                if ( sscanf( argv[++index], "%lf", &X  ) != 1) usage (-1);
                break;
            default:
                usage(-1);
        }
   }
   fp = fopen(file,"r");
   
   while ( fgets(ss,120,fp) != NULL ) {
      sscanf(ss,"%lf %lf", &x1, &y1);
      fprintf(stdout,"%lf %lf %lf\n", x1,y1,X);
   }
   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: newcol -f file -x X\n"); 
   exit( exitstatus );
}

