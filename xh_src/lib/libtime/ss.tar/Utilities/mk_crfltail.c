#include <stdio.h>
#include <math.h>

main(argc,argv)
int argc;
char **argv;
{
float srcdep,recdep;
float vred, tmin;
float phsvel1, phsvel2, phsvel3, phsvel4;
float dist1, dist2, ddist;
float strike, dip, rake, azm;
float deg2rad;
float dt=1.;
float f1, f2, f3, f4;

int nsamp = 2048;
int index = 0;
int ierr;
int nrayp;

char ss[80];

deg2rad = atan(1.)*4./180.;
//-----------------------
// preset values .....
recdep = 0.;		// receiver depth
vred   = 0.;		// reduction velocity
tmin   = 0.;		// begin time
phsvel1 = 3.;		// phase velocity window
phsvel2 = 4.;
phsvel3 = 30.;
phsvel4 = 40.;
f1      = 0.004;	// frequency window
f2      = 0.008;
dt      = 1.;		// delta t
nsamp   = 8192;		// delta t
//-----------------------

if(argc != 18) {
   ierr = usage();
   exit(-1);
}
while ( ++index < argc && argv[index][0] == '-' ) {
  switch ( argv[index][1] ) {
     case 'h':
        // source depth
        if ( sscanf( argv[++index], "%f", &srcdep ) != 1) {
            ierr = usage();
        }
        break;
     case 'd':
        // distances
        if ( sscanf( argv[++index], "%f %f", &dist1 ) != 1) {
            ierr = usage();
        }
        if ( sscanf( argv[++index], "%f %f", &dist2 ) != 1) {
            ierr = usage();
        }
        if ( sscanf( argv[++index], "%f %f", &ddist ) != 1) {
            ierr = usage();
        }
        break;
     case 'a':
        // azimuth
        if ( sscanf( argv[++index], "%f", &azm ) != 1) {
            ierr = usage();
        }
        break;
     case 's':
        // strike/dip/rake
        if ( sscanf( argv[++index], "%f", &strike ) != 1) {
            ierr = usage();
        }
        if ( sscanf( argv[++index], "%f", &dip ) != 1) {
            ierr = usage();
        }
        if ( sscanf( argv[++index], "%f", &rake ) != 1) {
            ierr = usage();
        }
        break;
     case 'n':
        // number of slownesses
        if ( sscanf( argv[++index], "%d", &nrayp ) != 1) {
            ierr = usage();
        }
        break;
     case 'f':
        // azimuth
        if ( sscanf( argv[++index], "%f", &f3 ) != 1) {
            ierr = usage();
        }
        if ( sscanf( argv[++index], "%f", &f4 ) != 1) {
            ierr = usage();
        }
        break;
     default:
        ierr = usage();
        exit(ierr);
  }
}



fprintf(stdout,"\n");
fprintf(stdout,"%10.4f\n", recdep);
fprintf(stdout,"%10.4f %9.4f %9.1f %9.1f %9.1f\n", 0., 0., srcdep, 0., 1.);
fprintf(stdout,"%10.4f %9.4f %9.4f\n", strike*deg2rad, dip*deg2rad, rake*deg2rad);
fprintf(stdout,"%10.3f %9.3f %9.3f %9.1f %9d\n", dist1*111.195, dist2*111.195, ddist*111.195, azm, 0);
fprintf(stdout,"%10.4f %9.4f\n", vred, tmin);
fprintf(stdout,"%10.4f %9.4f %9.4f %9.4f %9d\n", phsvel1,phsvel2,phsvel3,phsvel4,nrayp);
fprintf(stdout,"%10.4f %9.4f %9.4f %9.4f %9.4f\n", f1,f2,f3,f4,0.);
fprintf(stdout,"%10.3f %9d %9d %9d %9.2f %9.2f\n", dt, nsamp, 0, 2, 3*dt, nsamp*dt*0.35 );

}

int usage()
{
fprintf(stderr,"Usage: mk_crfltail -h SRCDEP -d DIST DIST2\n");
  return(-1);
}



