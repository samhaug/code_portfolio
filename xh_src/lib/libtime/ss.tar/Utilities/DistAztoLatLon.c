#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
 
/*
  Given Lat1, Lon1, this routine calculates Lat2, Lon2, 
  located at a distance Dist and azimuth Azi (clockwise from north).
*/
 
int main(argc, argv)
int argc;
char *argv[];
{
   double Lat1, Lon1, Lat2, Lon2, Dist, Az;
   double Theta, Phi, Theta2, Phi2;
   double DegToRad;

   double v[3];

   FILE *ff1, *fopen();
 
/*  Retrieving command line input: */
   if (argc != 5) {
      (void) printf("Usage:%s DistAz_to_LatLon Lat1 Lon1 Dist Az\n",argv[0]);
      exit(-1);
   } else {
      sscanf(argv[1],"%lf", &Lat1);
      sscanf(argv[2],"%lf", &Lon1);
      sscanf(argv[3],"%lf", &Dist);
      sscanf(argv[4],"%lf", &Az);
   }
DegToRad = atan(1.) * 4./180.;


Theta = 90. - Lat1;
Phi   = Lon1;

Lat1  *= DegToRad;
Lon1  *= DegToRad;
Dist  *= DegToRad;
Az    *= DegToRad;
Theta *= DegToRad;
Phi   *= DegToRad;

v[0] = sin(Theta)*cos(Phi); 
v[1] = sin(Theta)*sin(Phi);  
v[2] = cos(Theta);    

/* v = [1,0,0]:  Points from Earth's center through equator at Lon =  0. */
/* v = [0,1,0]:  Points from Earth's center through equator at Lon = 90. */
/* v = [0,0,1]:  Points from Earth's center through North Pole */

/* Translate v to Greenwich meridian (Lon = 0.): */
/* Rotate_M(v, Lon1); */

/* Translate v to equator (Lat = 0.): */
/* Rotate_E(v, Lat1); */

/* Rotate Azimuth to 0: */
/* Rotate_A(v, Az); */

/* Would we do these rotation we end up with: */
v[0] = 1.; v[1] = 0.; v[2] = 0.;

/* for arbritary Theta and Phi. */
/* So, v = [1,0,0], and we have Az = 0. */

/* Now translate v to the North by an amount of "Dist": */
Rotate_E(v, -1.0*Dist);

/* And do the inverse rotations ...*/

/* First Azimuth, corrects for the fact that the translation is in the direction Az from north: */
Rotate_A(v, -1.0*Az);

/* Then translate from (lat=0;lon=0) to original latitude Lat1: */
Rotate_E(v, -1.0*Lat1);

/* And translate to the original longitude Lon1: */
Rotate_M(v, -1.0*Lon1);


Theta2 = acos( v[2] );
Phi2   = acos( v[0]/sin(Theta2) );
if (v[1] < 0.)    Phi2 = -Phi2;
if (Phi2 < -180.) Phi2 = Phi2 + 360.;

Lat2 = 90. - Theta2/DegToRad;
Lon2 = Phi2/DegToRad;




Lat1 /= DegToRad;
Lon1 /= DegToRad;
Az   /= DegToRad;

/* fprintf(stdout,"Lat= %7.3f Lon=  %9.3f\n", Lat1, Lon1); */
/* fprintf(stdout,"Dist= %7.3f Az=  %7.3f\n", Dist, Az); */
fprintf(stdout,"%7.3f %9.3f\n", Lat2, Lon2);

exit(0);

}



/*-----------------------------------------------------------------*/
Rotate_M(v,phi)

double v[3];
double phi;
{

double a[3][3];
double x[3];
int i, j;

a[0][0] =  cos(phi); a[0][1] =  sin(phi); a[0][2] = 0.;
a[1][0] = -sin(phi); a[1][1] =  cos(phi); a[1][2] = 0.;
a[2][0] =  0.;       a[2][1] =  0.;       a[2][2] = 1.;

for(i=0;i<3;++i) {
  x[i] = 0.;
  for(j=0;j<3;++j) 
    x[i] = x[i] + a[i][j]*v[j]; 
  }

for(i=0;i<3;++i) 
  v[i] = x[i];

}

/*-----------------------------------------------------------------*/
Rotate_E(v,phi)

double v[3];
double phi;
{

double a[3][3];
double x[3];
int i, j;

a[0][0] =  cos(phi); a[0][1] = 0.; a[0][2] = sin(phi);
a[1][0] =  0.;       a[1][1] = 1.; a[1][2] = 0.;
a[2][0] = -sin(phi); a[2][1] = 0.; a[2][2] = cos(phi);

for(i=0;i<3;++i) {
  x[i] = 0.;
  for(j=0;j<3;++j) 
    x[i] = x[i] + a[i][j]*v[j]; 
  }

for(i=0;i<3;++i) 
  v[i] = x[i];

}

/*-----------------------------------------------------------------*/
Rotate_A(v,phi)

double v[3];
double phi;
{

double a[3][3];
double x[3];
int i, j;

a[0][0] =  1.; a[0][1] = 0.;        a[0][2] = 0.;
a[1][0] =  0.; a[1][1] =  cos(phi); a[1][2] = -sin(phi);
a[2][0] =  0.; a[2][1] =  sin(phi); a[2][2] = cos(phi);

for(i=0;i<3;++i) {
  x[i] = 0.;
  for(j=0;j<3;++j) 
    x[i] = x[i] + a[i][j]*v[j]; 
  }

for(i=0;i<3;++i) 
  v[i] = x[i];

}

