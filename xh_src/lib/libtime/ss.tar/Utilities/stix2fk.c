/*
Program to turn the PYRL output from Lars into seismic profiles
for FK
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

main(argc,argv)
int argc;
char **argv;
{
FILE *ifl;

int i, n_layers=0;
int k;

float dep[3000],rho[3000],vs[3000],vp[3000],qs[3000],qp[3000];
float Z_flat[3000],Pval_flat[3000],Sval_flat[3000],Rval_flat[3000];

float Pval, Sval, Rval, QPval, QSval;
float dz, z0, z;
float EarthRad, flat;
float src_depth, dist, reftime;

int   src_layer = 6;
int   numsamp = 2048;
float dt      = 1.00;

char ss[180];

if ((ifl = fopen(argv[1],"r")) == NULL) {
  fprintf(stderr,"%s cannot be opened ...\n", ifl);
  exit(-1);
}

EarthRad = 6371.;
i=0;
while ( fgets(ss,180,ifl) != NULL ) {
   sscanf(ss,"%*f %f %*f %f %*f %*f %*f %f %f %f %f %*f", &dep[i],&rho[i],&vs[i],&vp[i],&qs[i],&qp[i]);
   i = i+1;
   if (i == src_layer) {
     src_depth = dep[i-1];
   }
   
}
n_layers = i;
for(i=0;i<n_layers;i++) {
  flat   = EarthRad/(EarthRad - dep[i]);
  dep[i] = EarthRad * log(flat);
  vp[i]  = vp[i]  * flat;
  vs[i]  = vs[i]  * flat;
  // Kennett's suggestion for RHO flattening
  rho[i] = rho[i] / flat;
  // fprintf(stdout,"i= %d z= %f vp= %f vs= %f\n", i, dep[i], vp[i], vs[i]);
}

fprintf(stdout,"305 6 2\n");
z  = 0.;
while (z < 3870.){
  dz = 20.;
  if (z < 1700.) dz = 20.;
  if (z < 1100.) dz = 15.;
  if (z <  850.) dz =  5.;
  if (z <  330.) dz = 10.;
  if (z <  100.) dz =  6.;
  if (z <   33.) dz =  3.;
  z = z + dz;
  if (! interp(z, dep, vp, &Pval) ) {
     fprintf(stderr,"Error in interp() z= %f\n", z);
     exit(-1);
  }
  if (! interp(z, dep, vs, &Sval) ) {
     fprintf(stderr,"Error in interp() z= %f\n", z);
     exit(-1);
  }
  if (! interp(z, dep, rho, &Rval) ) {
     fprintf(stderr,"Error in interp() z= %f\n", z);
     exit(-1);
  }
  if (! interp(z, dep, qp, &QPval) ) {
     fprintf(stderr,"Error in interp() z= %f\n", z);
     exit(-1);
  }
  if (! interp(z, dep, qs, &QSval) ) {
     fprintf(stderr,"Error in interp() z= %f\n", z);
     exit(-1);
  }
  fprintf(stdout,"%6.2f %8.4f %8.4f %8.4f %8.1f %8.1f\n", dz, Pval, Sval, Rval, QPval, QSval);
}
fprintf(stdout,"2 %d %4.2f 0.5 0 1 1 1\n", numsamp, dt);
fprintf(stdout,"0 1 0.3 15\n");
fprintf(stdout,"90\n");
for(k=0;k<90;k++) {
  dist = (90+k)*111.195;
  if (! gettime(src_depth,(90+k)*1.,&reftime,"SS")) {
     fprintf(stderr,"Error in gettime() z= %f\n", z);
     exit(-1);
  }
  fprintf(stdout,"%8.2f %7.2f GrnFnc/%2d.SS.\n", dist, reftime-1000., 90+k);
}
  


}

int interp(z,dep,array,val)

float z;
float dep[3000];
float array[3000];
float *val;

{

int i=0;
float da, dz, dv; 

while (z > dep[i] )
   i++;

dz = dep[i] - dep[i-1];
da = array[i]-array[i-1];
dv = da/dz;

*val =  array[i-1] + (z-dep[i-1])*dv;

//fprintf(stdout,"INTERP i= %d  z= %f z1= %f z2 = %f\n", i, z,dep[i-1],dep[i]);
//fprintf(stdout,"INTERP v1= %f v2= %f val=%f \n", array[i-1],array[i], *val);
}
