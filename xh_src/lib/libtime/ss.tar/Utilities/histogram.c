/*
 * histogram - reads in a file with 1 columns and prints out 
  numerb of values within a certain range
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, n, norm=0, maxbin=1;
    float     min, max, bin;
    char      ss[120], file[80];
    float     y, r1, r2;
    int       bins[1000];
    FILE     *fp, *fopen();


   if (argc < 2) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case '1':
                if ( sscanf( argv[++index], "%f", &min ) != 1) usage (-1);
                break;
            case '2':
                if ( sscanf( argv[++index], "%f", &max ) != 1) usage (-1);
                break;
            case 'b':
                if ( sscanf( argv[++index], "%f", &bin ) != 1) usage (-1);
                break;
            case 'f':
                if ( sscanf( argv[++index], "%s", file ) != 1) usage (-1);
                break;
            case 'n':
                if ( sscanf( argv[++index], "%d", &norm ) != 1) usage (-1);
                break;
            default:
                usage(-1);
        }
   }
   fp = fopen(file,"r");
   n =  lrint((max - min)/bin);
   for (i=0; i<n; ++i) bins[i] = 0;
   
   while ( fgets(ss,120,fp) != NULL ) {
      sscanf(ss,"%f", &y);
      for (i=0; i<n; ++i) {
        r1 = i*bin + min - bin/2.;
        r2 = i*bin + min + bin/2.;
        if( y>=r1 && y<r2)  bins[i] = bins[i] + 1;
      }
   }
   if (norm) {
     maxbin = 0;
     for (i=0; i<n; ++i) {
        if (bins[i] > maxbin) maxbin = bins[i];
     }
     for (i=0; i<n; ++i)
       fprintf(stdout,"%f %f\n", min+i*bin,  1.*bins[i]/maxbin);
   } else {
     for (i=0; i<n; ++i) {
        fprintf(stdout,"%f %d\n", min+i*bin,  bins[i]);
     }
   }
   
   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: histogram -1 min -2 max -b bin -n norm [0,1] -f file\n"); 
   exit( exitstatus );
}

