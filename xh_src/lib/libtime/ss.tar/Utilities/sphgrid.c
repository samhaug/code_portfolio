/* program to place a grid of points with x degree spacing on a sphere */


#include <stdio.h>
#include <math.h>
#include <sunmath.h>
#include <sys/file.h>

void usage( );
double dist();
void rot_theta(), rot_phi();

main(argc, argv)
int argc;
char *argv[];

{
int i, j, numpoints;
int ilatstep, ilonstep;
double theta, phi;
float lat, lon, startlon, dlon;
float x;
double deg2rad;

deg2rad = atan(1.)*4./180.;

/*--------------------------------------*/
/* For 2 degree spacing: */
x = 2.;
ilatstep = 91;
ilonstep = 180.;

/* For 3 degree spacing: */
x = 3.;
ilatstep = 61;
ilonstep = 120.;
/*--------------------------------------*/

theta = 0.;
phi =   0.;
startlon = -180.;

for (i=0; i < ilatstep; ++i) { 
  theta = i*x;
  lat = 90.-theta;
  theta = theta*deg2rad;
  numpoints = aint(sin(theta)*ilonstep) + 1;
  dlon = 360./numpoints;
  for (j=0; j < numpoints; ++j) {
     lon = startlon + j*dlon;
     if (lon > 180.) lon = lon - 360.;
     fprintf(stdout, "%4.1f %7.1f\n", lat, lon);
  }
  if (numpoints > 1) {
     startlon = startlon + 0.5*dlon;
     if (startlon > 180.) startlon = startlon - 360.;
  }
}

}
