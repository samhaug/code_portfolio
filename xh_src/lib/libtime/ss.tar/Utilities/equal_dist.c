// program to print out (lat,lon) at a
// specified distance from (LAT,LON)
// output (Lon,lat) for use in a GMT script

// J. Ritsema 9/96
// Caltech

// ---------------------------------------------------------------------
// Does not work for a distance exactly 90 degrees (tan is not defined).
// My quick-and-dirty fix:
// If (arc_dist == 90) arc_dist = 89.999;
// ---------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void usage( );

main(argc, argv)
int argc;
char *argv[];

{
int i, index;
float phi;
float lat, lon, arc_dist;
float xlat, xlon;

index = 0;

if (argc < 4) usage(-1);
while ( ++index < argc ) {
  if ( argv[index][0] != '-' ) usage(-1);
  switch ( argv[index][1] ) {
    case 'l':
        if ( sscanf( argv[++index], "%f", &lat ) != 1 ||
             sscanf( argv[++index], "%f", &lon ) != 1 ) usage(-1);
        break;
    case 'g':
        if ( sscanf( argv[++index], "%f", &arc_dist ) != 1 ) usage(-1);
        break;
    default:
        usage(-1);
  } // switch
} // while

for (i=1;i<=360;++i) { 
  phi = i*1.; 
  if( ! distaz2latlon(lat,lon,arc_dist,phi,&xlat,&xlon) )
    exit(-1);

  if (xlon >= 180.) xlon -= 360.;
  if (xlon < -180.) xlon += 360.;

  fprintf(stdout,"%7.3f %6.3f\n", xlon,xlat);
} // for

}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: equal_dist  [-l lat lon] [-g dist (deg)]\n"); 
   exit( exitstatus );
}

