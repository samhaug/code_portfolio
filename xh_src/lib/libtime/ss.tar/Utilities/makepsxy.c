/*
 makePsxy - Take x1,y1,x2,y2 from line and write it as 
   >
   x1, y1
   x2, y2
*/

#include <stdio.h>
#include <string.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    char      ss[120], e1[20], e2[20], e3[20], e4[20];


   if (argc != 1) usage(-1);

   while ( fgets(ss,120,stdin) != NULL ) {
      sscanf(ss,"%s %s %s %s", e1, e2, e3, e4);
      fprintf(stdout,">\n");
      fprintf(stdout,"%s %s\n", e1, e2);
      fprintf(stdout,"%s %s\n", e3, e4);
   }

exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: makepsxy -o entry1 entry2 entry3 entry4]\n"); 
   exit( exitstatus );
}

