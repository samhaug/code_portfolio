#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <sys/param.h>

// Gets traveltime from TauP traveltime tables

main(argc,argv)
int argc;
char *argv[];
{

int   ierr, index;
float TTime;
float evdep, gcarc;
char phase[10];

int usage();

if(argc != 6) {
     ierr=usage();
     exit(-1);
}

// First argument is the Phase name
index = 1;
if ( sscanf(argv[index],"%s", phase) != 1) {
     ierr=usage();
     exit(-1);
}
while ( ++index < argc && argv[index][0] == '-' ) {
  switch ( argv[index][1] ) {
    case 'h':
      if ( sscanf(argv[++index],"%f",&evdep ) != 1) {
        ierr=usage();
        exit(-1);
      }
      break;
    case 'd':
      if ( sscanf(argv[++index],"%f",&gcarc ) != 1) {
        ierr=usage();
        exit(-1);
      }
      break;
    default:
      ierr = usage();
      exit(-1);
  }
}

// Get Pwave traveltime for depth and distance from TravelTimeTables
if (! gettime(evdep,gcarc,&TTime,phase))
  exit (-1);

fprintf(stdout,"PHASE= --%s-- H= %5.1fkm gcarc= %5.1f T= %6.2f\n", phase,evdep,gcarc,TTime);

}

int usage(flnm)
char *flnm;
        {
        fprintf(stderr,"Usage: getTTtime Phase -h evdep -d gcarc\n");
        return(-1);
}
