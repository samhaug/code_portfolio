/*
 * col2norm -- normalizes the
   nth (1 or 2) column
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

int main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, n;
    int       colnum;
    char      ss[120], infile[80];
    double    x[10000],y[10000], max;
    FILE     *fp1, *fopen();


   if (argc < 3) usage(-1);

   if ( sscanf( argv[1], "%s", infile ) != 1) usage (-1);
   index = 1;
   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'c':
                if ( sscanf( argv[++index], "%d", &colnum ) != 1) usage (-1);
                if ( colnum > 2 ) usage (-1);
                break;
            default:
                usage(-1);
        }
   }

   // reading data
   fp1 = fopen(infile,"r");
   i = 0;
   max = 0.;
   while ( fgets(ss,120,fp1) != NULL ) {
      sscanf(ss,"%lf %lf", &x[i], &y[i]);
      if (colnum == 1) {
         if( fabsf(x[i]) > max) max = fabsf(x[i]);
      }
      if (colnum == 2) {
         if( fabsf(y[i]) > max) max = fabsf(y[i]);
      }
      i++;
   }
   n = i;
// fprintf(stdout,"n= %d\n", n);

  for (i=0; i<n;i++) {
   if        (colnum == 1) {
     fprintf(stdout,"%lf %lf\n", x[i]/max, y[i]);
   } else if (colnum == 2) {
     fprintf(stdout,"%lf %lf\n", x[i],     y[i]/max);
   }
   }
   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: col2norm infile -c [column <= 2]\n"); 
   fprintf(stderr,"\n");
   fprintf(stderr,"Reads in a file with 2 columns and\n");
   fprintf(stderr,"divide the nth (1 or 2) column by its maximum value\n");
   exit( exitstatus );
}

