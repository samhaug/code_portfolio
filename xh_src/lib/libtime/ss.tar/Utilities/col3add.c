/*
 * col3add - reads in a file with 3 columns and
   add X to the nth (1 or 2 or 3) column
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    int       colnum;
    char      ss[120], file1[80], file2[80];
    double    x1,y1,z1, ADD;
    FILE     *fp1, *fopen();


   if (argc < 3) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case '1':
                if ( sscanf( argv[++index], "%s", file1 ) != 1) usage (-1);
                break;
            case 'c':
                if ( sscanf( argv[++index], "%d", &colnum ) != 1) usage (-1);
                if ( colnum > 3 ) usage (-1);
                break;
            case 'a':
                if ( sscanf( argv[++index], "%lf", &ADD ) != 1) usage (-1);
                break;
            default:
                usage(-1);
        }
   }
   fp1 = fopen(file1,"r");

   while ( fgets(ss,120,fp1) != NULL ) {
      sscanf(ss,"%lf %lf %lf", &x1, &y1, &z1);
      if        (colnum == 3) {
        fprintf(stdout,"%lf %lf %lf\n", x1, y1, z1+ADD);
      } else if (colnum == 2) {
        fprintf(stdout,"%lf %lf %lf\n", x1, y1+ADD, z1);
      } else if (colnum == 1) {
        fprintf(stdout,"%lf %lf %lf\n", x1+ADD, y1, z1);
      }
   }
   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: col3add -1 file1 -c [column <= 3] -a ADD\n"); 
   fprintf(stderr,"\n");
   fprintf(stderr,"Reads in a file with 3 columns and\n");
   fprintf(stderr,"add ADD to the nth (1 or 2 or 3) column.\n");
   exit( exitstatus );
}

