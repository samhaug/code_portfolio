/*
 * mkerrbar - reads in a three-column files: x, y1, y2
            - writes (i) ">"; (ii) "x y1"; "x y2"
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

void usage();

int main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    char      ss[120], inpfile[80];
    float    x, y1,y2;
    FILE     *ifp, *fopen();


   if (argc != 2) {
     fprintf(stderr,"Usage: mkerrbar IN_file\n"); 
     exit(-1);
   }

   sscanf( argv[1], "%s", inpfile );
   ifp = fopen(inpfile,"r");
   
   while ( fgets(ss,120,ifp) != NULL ) {
      sscanf(ss,"%f %f %f", &x, &y1, &y2);
      fprintf(stdout,">\n");
      fprintf(stdout,"%f %f\n", x, y1);
      fprintf(stdout,"%f %f\n", x, y2);
   }
}
