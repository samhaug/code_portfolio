//----------------------------------------------
//
// csh_gets
//
// reads a line from standard input
// See UNIX C-SHELL FIELD GUIDE page 341.
//
//----------------------------------------------

#include <stdio.h>

main( )
{
int c;

while (( c=getchar() ) != '\n' && c!= EOF)
  putchar(c);

putchar('\n');

}
