/*
 * norm3 - reads in file with 3 columns and normalises the nth (1, 2 or 3) column.
 *
 */

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    int       colnum, nlines;
    char      ss[120];
    double    x[90000], y[90000], z[90000];
    double    max;


   if (argc < 3) usage(-1);

   while ( ++index < argc && argv[index][0] == '-' ) {
        switch ( argv[index][1] ) {
            case 'n':
                if ( sscanf( argv[++index], "%d", &colnum ) != 1) usage (-1);
                if ( colnum > 3 ) usage (-1);
                break;
            default:
                usage(-1);
        }
   }

   i=0;
   max = 0.;
   if (colnum == 1) {
     while ( fgets(ss,120,stdin) != NULL ) {
        sscanf(ss,"%lf %lf %lf", &x[i], &y[i], &z[i]);
        if (fabs(x[i]) > max) {
          max = fabs(x[i]); 
        }
        i++;
     }
     nlines = i;
     for (i=1; i<nlines; ++i) 
       fprintf(stdout,"%lf %lf %lf\n", x[i]/max, y[i], z[i]);

   } else if (colnum == 2) {
     while ( fgets(ss,120,stdin) != NULL ) {
        sscanf(ss,"%lf %lf %lf", &x[i], &y[i], &z[i]);
        if (fabs(y[i]) > max) {
          max = fabs(y[i]);
        }
        i++;
     }
     nlines = i;
     for (i=1; i<nlines; ++i) 
       fprintf(stdout,"%lf %lf %lf\n", x[i], y[i]/max, z[i]);

   } else if (colnum == 3) {
     while ( fgets(ss,120,stdin) != NULL ) {
        sscanf(ss,"%lf %lf %lf", &x[i], &y[i], &z[i]);
        if (fabs(z[i]) > max) {
          max = fabs(z[i]);
        }
        i++;
     }
     nlines = i;
     for (i=1; i<nlines; ++i) 
       fprintf(stdout,"%lf %lf %lf\n", x[i], y[i], z[i]/max);

   } else {
     usage (-1);
   }

   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: norm3 -n column [column <= 3] \n"); 
   exit( exitstatus );
}

