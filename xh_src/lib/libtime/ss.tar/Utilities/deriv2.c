//
// deriv2 -
// reads in file with 2 columns (x,y)
// and prints x, dy/dx

#include <stdio.h>
#include <string.h>
#include <math.h>

void usage();

main( argc, argv )
int   argc;
char       *argv[];
{
    int       index = 0, i, j;
    int       i1, i2;
    int       colnum, nlines;
    char      ss[120];
    double    x[10000], y[10000];
    double    deriv1,deriv2;
    FILE     *fp;


   if (argc != 2) usage(-1);
   fp = fopen(argv[1],"r");

   i=0;
   while ( fgets(ss,120,fp) != NULL ) {
      sscanf(ss,"%lf %lf", &x[i], &y[i]);
      i++;
   }
   nlines = i;
   for (i=2; i<nlines-2; ++i) {
     deriv1= (y[i+1]-y[i-1])/(x[i+1]-x[i-1]);
     deriv2= (y[i+2]-y[i-2])/(x[i+2]-x[i-2]);
     fprintf(stdout,"%lf %lf\n", x[i], (deriv1+deriv2)/2.);
   }

   exit( 0 );
}

void    usage( exitstatus )
int     exitstatus;
{
   fprintf(stderr,"Usage: deriv2 XY_file\n"); 
   exit( exitstatus );
}

